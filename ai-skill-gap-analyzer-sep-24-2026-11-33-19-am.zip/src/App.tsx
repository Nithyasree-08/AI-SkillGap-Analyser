import React, { useState, useEffect, useMemo } from 'react';
import {
  StudentProfile,
  SkillScore,
  SkillGapItem,
  JobRecommendation,
  RecommendedSkillInfo
} from './types';
import {
  DEFAULT_PROFILE,
  ROLE_SKILL_REQUIREMENTS,
  SKILL_PLATFORMS,
  DEFAULT_PLATFORMS,
  INITIAL_JOBS
} from './data/constants';
import { getQuestionsForSkill } from './data/questions';
import {
  loadStoredProfile,
  saveStoredProfile,
  loadStoredScores,
  saveStoredScores
} from './utils/storage';

export default function App() {
  // Navigation State
  const [currentPage, setCurrentPage] = useState<'welcome' | 'profile' | 'analysis' | 'app'>('welcome');
  const [currentSubpage, setCurrentSubpage] = useState<'dashboard' | 'skills' | 'assessment' | 'gaps' | 'roadmap' | 'jobs' | 'progress' | 'profile2'>('dashboard');

  // Profile State
  const [profile, setProfile] = useState<StudentProfile>(loadStoredProfile);
  const [newSkillInput, setNewSkillInput] = useState('');
  const [showSkillInput, setShowSkillInput] = useState(false);

  // Analysis Loader State
  const [analysisReady, setAnalysisReady] = useState(false);

  // Assessment System State (Single, consolidated system)
  const [assessmentScores, setAssessmentScores] = useState<Record<string, SkillScore>>(loadStoredScores);
  const [activeAssessmentSkill, setActiveAssessmentSkill] = useState<string>('Python');
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [assessmentSubmitted, setAssessmentSubmitted] = useState<boolean>(false);
  const [assessmentError, setAssessmentError] = useState<string | null>(null);

  // Modal State for Job / Project Details
  const [activeJobModal, setActiveJobModal] = useState<JobRecommendation | null>(null);
  const [activeProjectModal, setActiveProjectModal] = useState<boolean>(false);

  // AI Assistant Chat State
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    { sender: 'ai', text: 'Hello! I am your AI Career Assistant. Ask me anything about your skill gaps, recommendations, or learning path.' }
  ]);

  // Persist Profile changes
  useEffect(() => {
    saveStoredProfile(profile);
  }, [profile]);

  // Persist Assessment Scores
  useEffect(() => {
    saveStoredScores(assessmentScores);
  }, [assessmentScores]);

  // Ensure activeAssessmentSkill belongs to student skills
  useEffect(() => {
    if (profile.skills.length > 0 && !profile.skills.includes(activeAssessmentSkill)) {
      setActiveAssessmentSkill(profile.skills[0]);
    }
  }, [profile.skills, activeAssessmentSkill]);

  // Reset selected answers when switching assessment skills (unless re-answering)
  const handleSelectSkillTab = (skill: string) => {
    setActiveAssessmentSkill(skill);
    setSelectedAnswers({});
    setAssessmentSubmitted(false);
    setAssessmentError(null);
  };

  // Questions for current active skill
  const currentQuestions = useMemo(() => {
    return getQuestionsForSkill(activeAssessmentSkill);
  }, [activeAssessmentSkill]);

  // -------------------------------------------------------------
  // CALCULATIONS (Evidence-based from assessment results)
  // -------------------------------------------------------------

  // Default baseline scores if a skill hasn't been assessed yet
  // We use transparent baseline defaults (e.g. 40% for Power BI, 25% for ML, 50% for unassessed)
  const getSkillPercentage = (skill: string): { percentage: number; isAssessed: boolean; score?: SkillScore } => {
    const assessed = assessmentScores[skill];
    if (assessed) {
      return { percentage: assessed.percentage, isAssessed: true, score: assessed };
    }
    // Baseline sample scores before assessment
    const baselines: Record<string, number> = {
      'Python': 80,
      'Excel': 85,
      'SQL': 60,
      'Statistics': 70,
      'Power BI': 40,
      'Machine Learning': 25,
      'Data Visualization': 45,
      'Advanced SQL': 55
    };
    return {
      percentage: baselines[skill] !== undefined ? baselines[skill] : 50,
      isAssessed: false
    };
  };

  // Overall Skill Match calculation
  const overallSkillMatch = useMemo(() => {
    const skillsToMeasure = profile.skills.length > 0 ? profile.skills : ['Python', 'SQL', 'Excel', 'Statistics'];
    let total = 0;
    skillsToMeasure.forEach(skill => {
      total += getSkillPercentage(skill).percentage;
    });
    return Math.round(total / skillsToMeasure.length);
  }, [profile.skills, assessmentScores]);

  // Skills Assessed count and Pending count
  const assessedCount = useMemo(() => {
    return profile.skills.filter(s => !!assessmentScores[s]).length;
  }, [profile.skills, assessmentScores]);

  const totalSkillsCount = profile.skills.length;
  const pendingSkills = useMemo(() => {
    return profile.skills.filter(s => !assessmentScores[s]);
  }, [profile.skills, assessmentScores]);
  const completedSkills = useMemo(() => {
    return profile.skills.filter(s => !!assessmentScores[s]);
  }, [profile.skills, assessmentScores]);
  const overallAssessmentProgress = totalSkillsCount > 0
    ? Math.round((assessedCount / totalSkillsCount) * 100)
    : 0;

  // Categorize assessed skills
  const categorizedSkills = useMemo(() => {
    const strong: Array<{ skill: string; percentage: number }> = [];
    const improve: Array<{ skill: string; percentage: number }> = [];
    const practice: Array<{ skill: string; percentage: number }> = [];

    const allSkills = Array.from(new Set([...profile.skills, 'Power BI', 'Machine Learning']));

    allSkills.forEach(skill => {
      const { percentage } = getSkillPercentage(skill);
      if (percentage >= 80) {
        strong.push({ skill, percentage });
      } else if (percentage >= 60) {
        improve.push({ skill, percentage });
      } else {
        practice.push({ skill, percentage });
      }
    });

    return { strong, improve, practice };
  }, [profile.skills, assessmentScores]);

  // Skill Gap Analysis items
  const skillGaps = useMemo<SkillGapItem[]>(() => {
    const requirements = ROLE_SKILL_REQUIREMENTS[profile.career] || ROLE_SKILL_REQUIREMENTS['Data Analyst'];
    const allSkills = Array.from(new Set([...profile.skills, ...Object.keys(requirements)]));

    return allSkills.map(skill => {
      const { percentage } = getSkillPercentage(skill);
      const req = requirements[skill] || 75;
      const rawGap = req - percentage;
      const isMet = rawGap <= 0;
      const gap = isMet ? 0 : rawGap;

      let priority: 'High' | 'Medium' | 'Low' | 'Completed' = 'Low';
      if (isMet) {
        priority = 'Completed';
      } else if (gap >= 30) {
        priority = 'High';
      } else if (gap >= 15) {
        priority = 'Medium';
      }

      let category: 'Strong' | 'Needs Improvement' | 'Needs More Practice' = 'Needs More Practice';
      if (percentage >= 80) category = 'Strong';
      else if (percentage >= 60) category = 'Needs Improvement';

      return {
        skill,
        currentLevel: percentage,
        requiredLevel: req,
        gap,
        isMet,
        priority,
        category
      };
    }).sort((a, b) => b.gap - a.gap); // largest gap first
  }, [profile.skills, profile.career, assessmentScores]);

  // Personalized Skill Recommendations (Prioritized by largest gap)
  const recommendedSkills = useMemo<RecommendedSkillInfo[]>(() => {
    return skillGaps
      .filter(item => !item.isMet)
      .slice(0, 4)
      .map(item => ({
        skill: item.skill,
        currentLevel: item.currentLevel,
        requiredLevel: item.requiredLevel,
        gap: item.gap,
        priority: item.priority === 'High' ? 'High' : item.priority === 'Medium' ? 'Medium' : 'Low',
        platforms: SKILL_PLATFORMS[item.skill] || DEFAULT_PLATFORMS
      }));
  }, [skillGaps]);

  // Dynamic Learning Roadmap based on student's weakest skills
  const dynamicRoadmapSteps = useMemo(() => {
    const weakest = skillGaps.filter(g => !g.isMet);
    const steps: Array<{ title: string; subtitle: string; status: string }> = [
      {
        title: 'Current Foundations',
        subtitle: `Assessed skills: ${assessedCount > 0 ? assessedCount + ' tested' : 'Baseline active'}`,
        status: 'Completed ✓'
      }
    ];

    if (weakest.length > 0) {
      steps.push({
        title: `Master ${weakest[0].skill}`,
        subtitle: `Current: ${weakest[0].currentLevel}% • Target: ${weakest[0].requiredLevel}% (Gap: ${weakest[0].gap}%)`,
        status: `${Math.round(weakest[0].currentLevel)}% complete`
      });
    }

    if (weakest.length > 1) {
      steps.push({
        title: `Advance in ${weakest[1].skill}`,
        subtitle: `Current: ${weakest[1].currentLevel}% • Target: ${weakest[1].requiredLevel}% (Gap: ${weakest[1].gap}%)`,
        status: `${Math.round(weakest[1].currentLevel)}% complete`
      });
    }

    if (weakest.length > 2) {
      steps.push({
        title: `Strengthen ${weakest[2].skill}`,
        subtitle: `Current: ${weakest[2].currentLevel}% • Target: ${weakest[2].requiredLevel}%`,
        status: `${Math.round(weakest[2].currentLevel)}% complete`
      });
    }

    steps.push({
      title: `Build 2 Capstone Projects (${profile.career} Portfolio)`,
      subtitle: 'Hands-on dataset analysis, dashboard design, and GitHub documentation',
      status: '1 of 2 complete'
    });

    steps.push({
      title: 'Update Resume & Apply for Industry Roles',
      subtitle: `Target Role: ${profile.career} • Match: ${overallSkillMatch}%`,
      status: 'Next career milestone'
    });

    return steps;
  }, [skillGaps, assessedCount, profile.career, overallSkillMatch]);

  // Dynamic Job Match calculations
  const dynamicJobs = useMemo(() => {
    return INITIAL_JOBS.map(job => {
      let totalMatch = 0;
      job.requiredSkills.forEach(skill => {
        totalMatch += getSkillPercentage(skill).percentage;
      });
      const matchScore = Math.round(totalMatch / job.requiredSkills.length);
      const skillsToImprove = job.requiredSkills.filter(s => getSkillPercentage(s).percentage < 70);

      return {
        ...job,
        computedMatch: matchScore,
        skillsToImprove
      };
    });
  }, [assessmentScores, profile.skills]);

  // -------------------------------------------------------------
  // HANDLERS
  // -------------------------------------------------------------

  // Profile Form changes
  const handleProfileFieldChange = (field: keyof StudentProfile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleAddSkill = () => {
    const trimmed = newSkillInput.trim();
    if (trimmed && !profile.skills.includes(trimmed)) {
      setProfile(prev => ({ ...prev, skills: [...prev.skills, trimmed] }));
      setNewSkillInput('');
      setShowSkillInput(false);
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setProfile(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skillToRemove)
    }));
  };

  const handleResumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setProfile(prev => ({
        ...prev,
        resume: e.target.files![0].name
      }));
    }
  };

  // Navigation handlers
  const handleNavigatePage = (page: 'welcome' | 'profile' | 'analysis' | 'app') => {
    if (page === 'analysis') {
      setAnalysisReady(false);
      setCurrentPage('analysis');
      setTimeout(() => {
        setAnalysisReady(true);
      }, 1600);
    } else {
      setCurrentPage(page);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavSubpage = (subpage: typeof currentSubpage) => {
    setCurrentSubpage(subpage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToLogin = () => {
    setCurrentPage('welcome');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Assessment Answer Selection
  const handleSelectOption = (questionId: number, optionIndex: number) => {
    if (assessmentSubmitted) return; // Prevent changing after submission until retake
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
    setAssessmentError(null);
  };

  // CONSOLIDATED SINGLE WORKING ASSESSMENT SUBMISSION
  const handleSubmitAssessment = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const questions = currentQuestions;
    const answeredCount = Object.keys(selectedAnswers).length;

    // Strict validation: must answer all 10 questions
    if (answeredCount < questions.length) {
      const missingCount = questions.length - answeredCount;
      setAssessmentError(`Please answer all ${questions.length} questions before submitting. (${missingCount} unanswered)`);
      return;
    }

    // Calculate score
    let correctCount = 0;
    questions.forEach(q => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        correctCount += 1;
      }
    });

    const percentage = Math.round((correctCount / questions.length) * 100);

    let status: 'Strong' | 'Needs Improvement' | 'Needs More Practice' = 'Needs More Practice';
    if (percentage >= 80) {
      status = 'Strong';
    } else if (percentage >= 60) {
      status = 'Needs Improvement';
    }

    const newScore: SkillScore = {
      skill: activeAssessmentSkill,
      correctAnswers: correctCount,
      totalQuestions: questions.length,
      percentage,
      status,
      completedAt: new Date().toISOString()
    };

    // Update state & localStorage
    setAssessmentScores(prev => ({
      ...prev,
      [activeAssessmentSkill]: newScore
    }));

    setAssessmentSubmitted(true);
    setAssessmentError(null);
  };

  // Retake Assessment for active skill
  const handleRetakeAssessment = () => {
    setSelectedAnswers({});
    setAssessmentSubmitted(false);
    setAssessmentError(null);
  };

  // Reset current answers during test
  const handleResetAnswers = () => {
    setSelectedAnswers({});
    setAssessmentError(null);
  };

  // AI Assistant query submission
  const handleAskAssistant = (questionText: string) => {
    if (!questionText.trim()) return;

    const userMsg = questionText.trim();
    setChatHistory(prev => [...prev, { sender: 'user', text: userMsg }]);
    setChatInput('');

    // Generate dynamic response grounded in latest assessment scores
    const weakest = skillGaps.filter(g => !g.isMet);
    const topWeak = weakest[0];
    const secondWeak = weakest[1];
    const topStrong = categorizedSkills.strong[0];

    let aiReply = '';
    const qLower = userMsg.toLowerCase();

    if (qLower.includes('what') && qLower.includes('next') || qLower.includes('learn')) {
      if (topWeak) {
        aiReply = `Based on your latest assessments, your biggest skill gap is in ${topWeak.skill} (Current: ${topWeak.currentLevel}%, Required: ${topWeak.requiredLevel}%). ${
          secondWeak ? `Your next priority is ${secondWeak.skill} (${secondWeak.currentLevel}%).` : ''
        } Focus on hands-on modules on ${topWeak.skill} before advancing to capstone projects.`;
      } else {
        aiReply = `Impressive! You have met the benchmark requirements across your assessed skills for ${profile.career}. Focus on building advanced full-scale projects to solidify your resume.`;
      }
    } else if (qLower.includes('how') || qLower.includes('become')) {
      aiReply = `To become an industry-ready ${profile.career}, bridge your current ${overallSkillMatch}% skill match to 90%+. Priority roadmap: 1) Master ${
        topWeak ? topWeak.skill : 'Advanced Analytics'
      }, 2) Practice real datasets on Kaggle/GitHub, 3) Build two showcase portfolio projects, and 4) Tailor your resume around measurable impact.`;
    } else if (qLower.includes('project')) {
      if (profile.career === 'Data Analyst') {
        aiReply = `Recommended Project: "Enterprise Sales & Customer Churn Analytics Dashboard". Use SQL to extract and transform customer transactions, Excel/Python to compute statistical cohorts, and Power BI to build interactive executive KPI dashboards.`;
      } else {
        aiReply = `Recommended Project for ${profile.career}: Build a real-world pipeline utilizing your strongest skill (${topStrong ? topStrong.skill : 'Python'}) alongside your growth area (${topWeak ? topWeak.skill : 'System Design'}). Document the repository cleanly on GitHub.`;
      }
    } else {
      aiReply = `Analyzing your profile for ${profile.career}: Your overall match is currently ${overallSkillMatch}%. You have ${
        topWeak ? `a ${topWeak.gap}% gap in ${topWeak.skill}` : 'strong fundamentals'
      }. Check the Learning Roadmap and Skill Gaps tabs for structured milestones!`;
    }

    setTimeout(() => {
      setChatHistory(prev => [...prev, { sender: 'ai', text: aiReply }]);
    }, 400);
  };

  // -------------------------------------------------------------
  // RENDER VIEWS
  // -------------------------------------------------------------

  return (
    <div>
      {/* ----------------- 1. WELCOME PAGE ----------------- */}
      {currentPage === 'welcome' && (
        <section id="welcome" className="page">
          <div className="container welcome">
            <div className="hero">
              <div className="brand">✦ AI Skill Gap Analyzer</div>
              <h1>
                Bridge the gap between your <span>skills</span> and your dream career.
              </h1>
              <p>
                Discover your skill gaps, build the right skills, and become industry-ready with a personalized career roadmap.
              </p>
              <div className="hero-actions">
                <button
                  type="button"
                  className="btn primary"
                  onClick={() => handleNavigatePage('profile')}
                >
                  Get Started →
                </button>
                <button
                  type="button"
                  className="btn secondary"
                  onClick={() => handleNavigatePage('profile')}
                >
                  Login
                </button>
              </div>
              <p className="small muted" style={{ marginTop: '25px' }}>
                Hackathon prototype • Evidence-based assessment data
              </p>
            </div>
            <div className="illustration">
              <div className="circle" style={{ width: '130px', height: '130px', right: '12%', top: '8%' }}></div>
              <div className="person">
                <div className="head"></div>
              </div>
              <div className="screen">
                <i></i>
                <i></i>
                <i></i>
                <i style={{ width: '85%' }}></i>
              </div>
              <div className="badge b1">📊 Skill Analysis</div>
              <div className="badge b2">🎯 Career Goal</div>
            </div>
          </div>
        </section>
      )}

      {/* ----------------- 2. PROFILE FORM PAGE ----------------- */}
      {currentPage === 'profile' && (
        <section id="profile" className="page">
          <div className="form-wrap">
            <div className="topbar">
              <div className="brand">✦ AI Skill Gap Analyzer</div>
              <button
                type="button"
                className="btn secondary"
                onClick={() => handleNavigatePage('welcome')}
              >
                ← Back
              </button>
            </div>
            <div className="card">
              <h2>Build your student profile</h2>
              <p className="muted">Tell us about yourself so we can create a personalized skill analysis.</p>

              <div className="grid2">
                <div className="field">
                  <label htmlFor="nameInput">Student Name</label>
                  <input
                    id="nameInput"
                    type="text"
                    value={profile.name}
                    onChange={e => handleProfileFieldChange('name', e.target.value)}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="field">
                  <label htmlFor="eduInput">Education</label>
                  <input
                    id="eduInput"
                    type="text"
                    value={profile.education}
                    onChange={e => handleProfileFieldChange('education', e.target.value)}
                    placeholder="e.g. B.Tech Computer Science"
                  />
                </div>
                <div className="field">
                  <label htmlFor="branchInput">Branch / Department</label>
                  <input
                    id="branchInput"
                    type="text"
                    value={profile.branch}
                    onChange={e => handleProfileFieldChange('branch', e.target.value)}
                    placeholder="e.g. Computer Science"
                  />
                </div>
                <div className="field">
                  <label htmlFor="yearSelect">Year of Study</label>
                  <select
                    id="yearSelect"
                    value={profile.year}
                    onChange={e => handleProfileFieldChange('year', e.target.value)}
                  >
                    <option value="1st Year">1st Year</option>
                    <option value="2nd Year">2nd Year</option>
                    <option value="3rd Year">3rd Year</option>
                    <option value="4th Year">4th Year</option>
                  </select>
                </div>
                <div className="field" style={{ gridColumn: 'span 2' }}>
                  <label htmlFor="careerSelect">Career Goal</label>
                  <select
                    id="careerSelect"
                    value={profile.career}
                    onChange={e => handleProfileFieldChange('career', e.target.value)}
                  >
                    <option value="Data Analyst">Data Analyst</option>
                    <option value="Software Developer">Software Developer</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="AI/ML Engineer">AI/ML Engineer</option>
                    <option value="Web Developer">Web Developer</option>
                    <option value="Cybersecurity Analyst">Cybersecurity Analyst</option>
                  </select>
                </div>
              </div>

              <div className="section">
                <h3>Your Current Skills</h3>
                <div className="skills">
                  {profile.skills.map(skill => (
                    <span key={skill} className="skill">
                      {skill}
                      <button
                        type="button"
                        onClick={() => handleRemoveSkill(skill)}
                        style={{ background: 'none', color: '#8892b0', fontSize: '15px', marginLeft: '4px' }}
                        title="Remove skill"
                      >
                        ×
                      </button>
                    </span>
                  ))}

                  {showSkillInput ? (
                    <div style={{ display: 'inline-flex', gap: '6px', alignItems: 'center' }}>
                      <input
                        type="text"
                        placeholder="e.g. Tableau"
                        value={newSkillInput}
                        onChange={e => setNewSkillInput(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddSkill();
                          }
                        }}
                        style={{
                          padding: '6px 10px',
                          borderRadius: '20px',
                          border: '1px solid var(--blue)',
                          fontSize: '13px',
                          outline: 'none'
                        }}
                        autoFocus
                      />
                      <button
                        type="button"
                        className="btn primary"
                        style={{ padding: '6px 12px', fontSize: '12px' }}
                        onClick={handleAddSkill}
                      >
                        Add
                      </button>
                      <button
                        type="button"
                        className="btn secondary"
                        style={{ padding: '6px 10px', fontSize: '12px' }}
                        onClick={() => {
                          setShowSkillInput(false);
                          setNewSkillInput('');
                        }}
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="skill"
                      style={{ cursor: 'pointer', background: '#fff', border: '1px dashed #cbd2e7' }}
                      onClick={() => setShowSkillInput(true)}
                    >
                      + Add Skill
                    </button>
                  )}
                </div>
              </div>

              <div className="upload">
                <p style={{ margin: 0 }}>
                  📄 <b>Upload Resume</b>
                </p>
                <span className="muted small">PDF or DOCX • Prototype upload area</span>
                <br />
                <button
                  type="button"
                  className="btn secondary"
                  style={{ marginTop: '12px' }}
                  onClick={() => document.getElementById('resumeFileInput')?.click()}
                >
                  Choose File
                </button>
                <input
                  id="resumeFileInput"
                  type="file"
                  accept=".pdf,.doc,.docx"
                  style={{ display: 'none' }}
                  onChange={handleResumeChange}
                />
                <div
                  id="resumeName"
                  className="small"
                  style={{
                    marginTop: '8px',
                    color: profile.resume !== 'Not selected' ? 'var(--green)' : 'var(--muted)',
                    fontWeight: 600
                  }}
                >
                  {profile.resume !== 'Not selected' ? `Selected: ${profile.resume}` : 'No resume file selected'}
                </div>
              </div>

              <button
                type="button"
                className="btn primary"
                style={{ marginTop: '20px', width: '100%' }}
                onClick={() => handleNavigatePage('analysis')}
              >
                Analyze My Skills →
              </button>
            </div>
          </div>
        </section>
      )}

      {/* ----------------- 3. ANALYSIS LOADING PAGE ----------------- */}
      {currentPage === 'analysis' && (
        <section id="analysis" className="page">
          <div className="analysis">
            <div className="brand" style={{ justifyContent: 'center' }}>✦ AI Skill Gap Analyzer</div>

            {!analysisReady ? (
              <div>
                <div className="loader"></div>
                <h2 id="analysisTitle">Analyzing {profile.name}'s profile for {profile.career}...</h2>
                <div className="checks">
                  <div><b>✓</b> Resume analyzed</div>
                  <div><b>✓</b> Skills extracted ({profile.skills.length} skills recognized)</div>
                  <div><b>✓</b> Industry requirements analyzed for {profile.career}</div>
                  <div><b>✓</b> Skill assessment framework prepared</div>
                </div>
              </div>
            ) : (
              <div id="analysisDone">
                <div style={{ fontSize: '48px', margin: '20px 0 10px' }}>🎯</div>
                <h2>Your profile analysis is ready!</h2>
                <p style={{ color: 'var(--blue)', fontWeight: 600, fontSize: '17px', maxWidth: '580px', margin: '10px auto 20px' }}>
                  Complete your skill assessment to generate your personalized skill-gap analysis.
                </p>

                <div className="card" style={{ textAlign: 'left', margin: '20px auto', maxWidth: '620px' }}>
                  <h3 style={{ borderBottom: '1px solid var(--line)', paddingBottom: '10px', marginBottom: '14px' }}>
                    Student Profile Snapshot
                  </h3>
                  <p><b>Student:</b> <span>{profile.name}</span></p>
                  <p><b>Education:</b> <span>{profile.education}</span></p>
                  <p><b>Branch:</b> <span>{profile.branch}</span></p>
                  <p><b>Year:</b> <span>{profile.year}</span></p>
                  <p><b>Career Goal:</b> <span>{profile.career}</span></p>
                  <p><b>Current Skills:</b> <span>{profile.skills.join(', ')}</span></p>
                  <p><b>Resume:</b> <span>{profile.resume}</span></p>
                </div>

                <div style={{ display: 'flex', gap: '14px', justifyContent: 'center', flexWrap: 'wrap' }}>
                  <button
                    type="button"
                    className="btn primary"
                    onClick={() => {
                      handleNavigatePage('app');
                      handleNavSubpage('assessment');
                    }}
                  >
                    Take Skill Assessment →
                  </button>
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={() => {
                      handleNavigatePage('app');
                      handleNavSubpage('dashboard');
                    }}
                  >
                    View Dashboard
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* ----------------- 4. MAIN APP WITH SIDEBAR & SUBPAGES ----------------- */}
      {currentPage === 'app' && (
        <section id="app" className="page">
          <div className="app">
            {/* SIDEBAR NAVIGATION */}
            <aside className="side">
              <div className="brand">
                ✦ <span>Skill Gap AI</span>
              </div>
              <div className="nav">
                <button
                  type="button"
                  className={currentSubpage === 'dashboard' ? 'active' : ''}
                  onClick={() => handleNavSubpage('dashboard')}
                >
                  ▣ <span>Dashboard</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'skills' ? 'active' : ''}
                  onClick={() => handleNavSubpage('skills')}
                >
                  ◈ <span>My Skills</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'assessment' ? 'active' : ''}
                  onClick={() => handleNavSubpage('assessment')}
                >
                  ✎ <span>Skill Assessment</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'gaps' ? 'active' : ''}
                  onClick={() => handleNavSubpage('gaps')}
                >
                  ⚠ <span>Skill Gaps</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'roadmap' ? 'active' : ''}
                  onClick={() => handleNavSubpage('roadmap')}
                >
                  ➜ <span>Learning Roadmap</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'jobs' ? 'active' : ''}
                  onClick={() => handleNavSubpage('jobs')}
                >
                  ⌁ <span>Recommended Jobs</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'progress' ? 'active' : ''}
                  onClick={() => handleNavSubpage('progress')}
                >
                  ↗ <span>Progress</span>
                </button>
                <button
                  type="button"
                  className={currentSubpage === 'profile2' ? 'active' : ''}
                  onClick={() => handleNavSubpage('profile2')}
                >
                  ○ <span>Profile</span>
                </button>

                <div style={{ height: '1px', background: '#e7eaf2', margin: '18px 8px' }}></div>

                <button
                  type="button"
                  onClick={handleGoToLogin}
                  style={{ color: '#d9534f' }}
                >
                  ↩ <span>Back to Login</span>
                </button>
              </div>
            </aside>

            {/* MAIN CONTENT AREA */}
            <main className="main">
              {/* HEADER */}
              <div className="mainhead">
                <div>
                  <h2 id="pageHeading">
                    {currentSubpage === 'dashboard' && `Welcome, ${profile.name} 👋`}
                    {currentSubpage === 'skills' && 'My Skills'}
                    {currentSubpage === 'assessment' && 'Skill Assessment'}
                    {currentSubpage === 'gaps' && 'Skill Gap Analysis'}
                    {currentSubpage === 'roadmap' && 'Learning Roadmap'}
                    {currentSubpage === 'jobs' && 'Recommended Jobs'}
                    {currentSubpage === 'progress' && 'Progress'}
                    {currentSubpage === 'profile2' && 'Student Profile'}
                  </h2>
                  <p className="muted" style={{ margin: 0 }}>
                    Target Role: <b>{profile.career}</b> • {assessedCount} of {profile.skills.length} skills assessed
                  </p>
                </div>
                <div className="avatar" title={profile.name}>
                  {profile.name.charAt(0).toUpperCase()}
                </div>
              </div>

              {/* ----------------- SUBPAGE: DASHBOARD ----------------- */}
              {currentSubpage === 'dashboard' && (
                <div id="dashboardPage">
                  {/* Top Stats */}
                  <div className="stats">
                    <div className="card stat">
                      <span className="muted small">Overall Skill Match</span>
                      <strong style={{ color: 'var(--blue)' }}>{overallSkillMatch}%</strong>
                      <p className="muted small">Target: 90%</p>
                    </div>
                    <div className="card stat">
                      <span className="muted small">Skills Assessed</span>
                      <strong>{assessedCount} / {profile.skills.length}</strong>
                      <p className="muted small">
                        {assessedCount === profile.skills.length ? 'All assessed ✓' : 'Take more tests'}
                      </p>
                    </div>
                    <div className="card stat">
                      <span className="muted small">Projects</span>
                      <strong>2</strong>
                      <p className="muted small">Completed</p>
                    </div>
                    <div className="card stat">
                      <span className="muted small">Courses</span>
                      <strong>3</strong>
                      <p className="muted small">Completed</p>
                    </div>
                  </div>

                  {/* Grid: Circular Ring & Skill Snapshot */}
                  <div className="dashboard-grid">
                    <div className="card" style={{ textAlign: 'center' }}>
                      <h3 style={{ textAlign: 'left' }}>Skill Match for {profile.career}</h3>
                      <div
                        className="progress-ring"
                        style={{
                          background: `conic-gradient(var(--blue) ${overallSkillMatch}%, #e8ebf4 0)`
                        }}
                      >
                        <div className="ringtext">
                          {overallSkillMatch}%
                          <small>aligned</small>
                        </div>
                      </div>
                      <p style={{ textAlign: 'center', marginTop: '15px' }} className="muted">
                        You are <b>{overallSkillMatch}%</b> aligned with your target {profile.career} role.
                      </p>
                      <button
                        type="button"
                        className="btn primary"
                        style={{ marginTop: '10px' }}
                        onClick={() => handleNavSubpage('assessment')}
                      >
                        Take Skill Assessment
                      </button>
                    </div>

                    <div className="card">
                      <h3>Skill Snapshot</h3>
                      <div className="skills-grid">
                        <div className="skillbox">
                          <h3 className="green">✓ Strong</h3>
                          <ul>
                            {categorizedSkills.strong.length > 0 ? (
                              categorizedSkills.strong.map(s => (
                                <li key={s.skill}>
                                  {s.skill} — <b>{s.percentage}%</b>
                                </li>
                              ))
                            ) : (
                              <li className="muted small">No strong skills yet</li>
                            )}
                          </ul>
                        </div>
                        <div className="skillbox">
                          <h3 className="yellow">⚠ Improve</h3>
                          <ul>
                            {categorizedSkills.improve.length > 0 ? (
                              categorizedSkills.improve.map(s => (
                                <li key={s.skill}>
                                  {s.skill} — <b>{s.percentage}%</b>
                                </li>
                              ))
                            ) : (
                              <li className="muted small">None in this range</li>
                            )}
                          </ul>
                        </div>
                        <div className="skillbox">
                          <h3 className="red">✕ Practice</h3>
                          <ul>
                            {categorizedSkills.practice.length > 0 ? (
                              categorizedSkills.practice.map(s => (
                                <li key={s.skill}>
                                  {s.skill} — <b>{s.percentage}%</b>
                                </li>
                              ))
                            ) : (
                              <li className="muted small">No low skills</li>
                            )}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Dynamic Skill Gap Bars */}
                  <div className="card section">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                      <div>
                        <h3 style={{ margin: 0 }}>Your Skill Gap & Competency</h3>
                        <p className="muted small" style={{ margin: 0 }}>
                          Calculated directly from student profile and assessment test results
                        </p>
                      </div>
                      <button
                        type="button"
                        className="btn secondary"
                        style={{ padding: '8px 14px', fontSize: '13px' }}
                        onClick={() => handleNavSubpage('assessment')}
                      >
                        Take Assessments
                      </button>
                    </div>

                    {profile.skills.map(skill => {
                      const { percentage, isAssessed } = getSkillPercentage(skill);
                      return (
                        <div key={skill}>
                          <div className="rowlabel">
                            <span>
                              <b>{skill}</b>
                              {isAssessed && (
                                <span style={{ marginLeft: '8px', fontSize: '11px', color: 'var(--green)' }}>
                                  ✓ Assessed
                                </span>
                              )}
                            </span>
                            <b>{percentage}%</b>
                          </div>
                          <div className="bar">
                            <i style={{ width: `${percentage}%` }}></i>
                          </div>
                        </div>
                      );
                    })}

                    <h3 style={{ marginTop: '20px' }}>Top Skills to Learn</h3>
                    {recommendedSkills.slice(0, 3).map((item, idx) => (
                      <p key={item.skill}>
                        {idx + 1}. <b>{item.skill}</b> (Current: {item.currentLevel}% • Required: {item.requiredLevel}%) —{' '}
                        <span className={`tag ${item.priority === 'High' ? 'tag-high' : item.priority === 'Medium' ? 'tag-medium' : 'tag-low'}`}>
                          {item.priority} Priority (Gap: {item.gap}%)
                        </span>
                      </p>
                    ))}

                    <button
                      type="button"
                      className="btn primary"
                      style={{ marginTop: '10px' }}
                      onClick={() => handleNavSubpage('roadmap')}
                    >
                      View Learning Roadmap
                    </button>
                  </div>

                  {/* Recommended For You Section */}
                  <div className="section">
                    <h3>Recommended for You</h3>
                    <div className="recs">
                      <div className="card rec">
                        <h3>📚 Learn</h3>
                        <b>{recommendedSkills[0] ? recommendedSkills[0].skill : 'Power BI'} Mastery</b>
                        <p>
                          Build interactive dashboards and reports aligned with {profile.career} industry expectations.
                        </p>
                        <button
                          type="button"
                          className="btn secondary"
                          onClick={() => {
                            if (recommendedSkills[0] && recommendedSkills[0].platforms[0]) {
                              window.open(recommendedSkills[0].platforms[0].url, '_blank', 'noopener,noreferrer');
                            } else {
                              handleNavSubpage('roadmap');
                            }
                          }}
                        >
                          Start Learning
                        </button>
                      </div>

                      <div className="card rec">
                        <h3>🛠 Build</h3>
                        <b>Sales & Operations Analytics Dashboard</b>
                        <p>Practice Power BI, SQL, Python, and statistical cohorts on real customer datasets.</p>
                        <button
                          type="button"
                          className="btn secondary"
                          onClick={() => setActiveProjectModal(true)}
                        >
                          View Project
                        </button>
                      </div>

                      <div className="card rec">
                        <h3>⌘ Practice</h3>
                        <b>{recommendedSkills[1] ? recommendedSkills[1].skill : 'SQL'} Assessment</b>
                        <p>Sharpen query logic, window functions, and relational schema optimization.</p>
                        <button
                          type="button"
                          className="btn secondary"
                          onClick={() => {
                            const target = recommendedSkills[1] ? recommendedSkills[1].skill : 'SQL';
                            handleSelectSkillTab(target);
                            handleNavSubpage('assessment');
                          }}
                        >
                          Practice Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: MY SKILLS ----------------- */}
              {currentSubpage === 'skills' && (
                <div id="skillsPage">
                  <div className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                      <h2 className="page-title" style={{ margin: 0 }}>My Skills</h2>
                      <button
                        type="button"
                        className="btn primary"
                        style={{ padding: '8px 14px', fontSize: '13px' }}
                        onClick={() => handleNavSubpage('assessment')}
                      >
                        ✎ Take Assessment
                      </button>
                    </div>

                    <p className="muted small">
                      Skills are updated automatically from your latest assessment tests.
                    </p>

                    <h3>Assessed & Current Skills</h3>
                    <div className="skills" style={{ marginBottom: '24px' }}>
                      {profile.skills.map(skill => {
                        const { percentage, isAssessed } = getSkillPercentage(skill);
                        return (
                          <div
                            key={skill}
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '8px',
                              padding: '8px 14px',
                              background: isAssessed ? '#eaf8f0' : '#eef2ff',
                              color: isAssessed ? '#107c41' : '#4459c7',
                              borderRadius: '20px',
                              fontSize: '14px',
                              fontWeight: 600,
                              border: isAssessed ? '1px solid #b7ebd0' : '1px solid transparent'
                            }}
                          >
                            <span>{skill} • {percentage}%</span>
                            <button
                              type="button"
                              onClick={() => {
                                handleSelectSkillTab(skill);
                                handleNavSubpage('assessment');
                              }}
                              style={{
                                background: 'transparent',
                                fontSize: '12px',
                                textDecoration: 'underline',
                                color: isAssessed ? '#0e6937' : '#3348b0',
                                padding: 0
                              }}
                            >
                              {isAssessed ? 'Retake' : 'Test'}
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    <h3>Skills to Develop for {profile.career}</h3>
                    <div className="skills">
                      {['Power BI', 'Machine Learning', 'Data Visualization', 'Advanced SQL']
                        .filter(s => !profile.skills.includes(s))
                        .map(skill => {
                          const { percentage } = getSkillPercentage(skill);
                          return (
                            <div
                              key={skill}
                              style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '8px',
                                padding: '8px 14px',
                                background: '#fff2d9',
                                color: '#a06c0b',
                                borderRadius: '20px',
                                fontSize: '14px',
                                fontWeight: 600
                              }}
                            >
                              <span>{skill} • {percentage}%</span>
                              <button
                                type="button"
                                onClick={() => {
                                  if (!profile.skills.includes(skill)) {
                                    setProfile(prev => ({ ...prev, skills: [...prev.skills, skill] }));
                                  }
                                  handleSelectSkillTab(skill);
                                  handleNavSubpage('assessment');
                                }}
                                style={{
                                  background: 'transparent',
                                  fontSize: '12px',
                                  textDecoration: 'underline',
                                  color: '#7b5003',
                                  padding: 0
                                }}
                              >
                                Assess Now
                              </button>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: SKILL ASSESSMENT ----------------- */}
              {currentSubpage === 'assessment' && (
                <div id="assessmentPage">
                  {/* Overall Skill Assessments Completion Progress Card */}
                  <div className="card assessment-overview-card" style={{ marginBottom: '20px', padding: '20px 24px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px' }}>
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <h2 style={{ margin: 0, fontSize: '20px' }}>Overall Assessment Completion</h2>
                          <span
                            style={{
                              background: overallAssessmentProgress === 100 ? '#e6f8ee' : '#eef2ff',
                              color: overallAssessmentProgress === 100 ? 'var(--green)' : 'var(--blue)',
                              fontSize: '12px',
                              fontWeight: 700,
                              padding: '4px 10px',
                              borderRadius: '20px',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '5px'
                            }}
                          >
                            {overallAssessmentProgress === 100 ? 'All Completed ✓' : `${pendingSkills.length} Pending Assessment${pendingSkills.length === 1 ? '' : 's'}`}
                          </span>
                        </div>
                        <p className="muted small" style={{ margin: '6px 0 0' }}>
                          Track your progress through all your profile skills. Completed assessments feed your dynamic dashboard match rate.
                        </p>
                      </div>

                      <div style={{ textAlign: 'right', minWidth: '130px' }}>
                        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'flex-end', gap: '4px' }}>
                          <span style={{ fontSize: '28px', fontWeight: 800, color: 'var(--blue)', lineHeight: 1 }}>
                            {overallAssessmentProgress}%
                          </span>
                        </div>
                        <span className="muted small" style={{ fontWeight: 600 }}>
                          {assessedCount} of {totalSkillsCount} Skills Assessed
                        </span>
                      </div>
                    </div>

                    {/* Visual Progress Bar for All Skills */}
                    <div
                      style={{
                        margin: '16px 0 10px',
                        background: '#edf0f6',
                        borderRadius: '12px',
                        height: '14px',
                        overflow: 'hidden',
                        position: 'relative',
                        boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.08)'
                      }}
                      role="progressbar"
                      aria-valuenow={overallAssessmentProgress}
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-label="Overall assessment completion progress"
                    >
                      <div
                        style={{
                          height: '100%',
                          width: `${overallAssessmentProgress}%`,
                          background: overallAssessmentProgress === 100
                            ? 'linear-gradient(90deg, #20a66a, #107c41)'
                            : 'linear-gradient(90deg, var(--blue), var(--purple))',
                          borderRadius: '12px',
                          transition: 'width 0.6s cubic-bezier(0.4, 0, 0.2, 1)',
                          boxShadow: '0 2px 8px rgba(79, 109, 245, 0.35)'
                        }}
                      />
                    </div>

                    {/* Pending vs Completed Breakdown Badges */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px', fontSize: '13px', marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed var(--line)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ color: 'var(--muted)', fontWeight: 600 }}>Pending ({pendingSkills.length}):</span>
                        {pendingSkills.length === 0 ? (
                          <span style={{ color: 'var(--green)', fontWeight: 700 }}>None! All skills evaluated ✓</span>
                        ) : (
                          pendingSkills.map(skill => (
                            <button
                              key={skill}
                              type="button"
                              onClick={() => handleSelectSkillTab(skill)}
                              style={{
                                background: skill === activeAssessmentSkill ? '#e0e7ff' : '#f1f3f9',
                                color: skill === activeAssessmentSkill ? 'var(--blue)' : 'var(--text)',
                                border: skill === activeAssessmentSkill ? '1px solid var(--blue)' : '1px solid transparent',
                                padding: '3px 9px',
                                borderRadius: '12px',
                                fontSize: '12px',
                                fontWeight: skill === activeAssessmentSkill ? 700 : 500,
                                cursor: 'pointer'
                              }}
                              title={`Take ${skill} assessment now`}
                            >
                              {skill} →
                            </button>
                          ))
                        )}
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ color: 'var(--muted)', fontWeight: 600 }}>Completed ({completedSkills.length}):</span>
                        {completedSkills.map(skill => (
                          <span
                            key={skill}
                            style={{
                              background: '#e6f8ee',
                              color: '#107c41',
                              padding: '2px 8px',
                              borderRadius: '12px',
                              fontSize: '11px',
                              fontWeight: 700
                            }}
                          >
                            {skill} {assessmentScores[skill]?.percentage}%
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Skill Tabs */}
                  <div className="assessment-tabs">
                    {profile.skills.map(skill => {
                      const score = assessmentScores[skill];
                      const isActive = skill === activeAssessmentSkill;
                      return (
                        <button
                          key={skill}
                          type="button"
                          className={`assessment-tab ${isActive ? 'active' : ''} ${score ? 'completed' : ''}`}
                          onClick={() => handleSelectSkillTab(skill)}
                        >
                          {skill}
                          {score ? (
                            <span style={{ fontSize: '12px', fontWeight: 800 }}>({score.percentage}%)</span>
                          ) : (
                            <span style={{ fontSize: '11px', opacity: 0.7 }}>[Pending]</span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* When Assessment is Submitted: Show Results Card */}
                  {assessmentSubmitted && assessmentScores[activeAssessmentSkill] ? (
                    <div className="card result-card">
                      <div style={{ fontSize: '48px', color: 'var(--green)' }}>✓</div>
                      <h2 style={{ marginBottom: '6px' }}>Assessment Completed</h2>
                      <p className="muted" style={{ marginBottom: '15px' }}>
                        Your results have been calculated and saved to your dashboard.
                      </p>

                      <div style={{ maxWidth: '420px', margin: 'auto', background: '#fafbff', borderRadius: '14px', padding: '20px', border: '1px solid var(--line)' }}>
                        <p style={{ margin: '6px 0', fontSize: '16px' }}>
                          <b>Skill:</b> <span style={{ color: 'var(--blue)', fontWeight: 700 }}>{activeAssessmentSkill}</span>
                        </p>
                        <div className="score-badge">
                          {assessmentScores[activeAssessmentSkill].correctAnswers} / {assessmentScores[activeAssessmentSkill].totalQuestions}
                        </div>
                        <p style={{ margin: '6px 0', fontSize: '18px' }}>
                          <b>Skill Level:</b> <strong style={{ color: 'var(--blue)' }}>{assessmentScores[activeAssessmentSkill].percentage}%</strong>
                        </p>
                        <div>
                          <b>Status:</b>{' '}
                          <span
                            className={`status-chip ${
                              assessmentScores[activeAssessmentSkill].status === 'Strong'
                                ? 'strong'
                                : assessmentScores[activeAssessmentSkill].status === 'Needs Improvement'
                                ? 'improve'
                                : 'practice'
                            }`}
                          >
                            {assessmentScores[activeAssessmentSkill].status === 'Strong' && '✓ Strong'}
                            {assessmentScores[activeAssessmentSkill].status === 'Needs Improvement' && '⚠ Needs Improvement'}
                            {assessmentScores[activeAssessmentSkill].status === 'Needs More Practice' && '✕ Needs More Practice'}
                          </span>
                        </div>
                      </div>

                      <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '24px', flexWrap: 'wrap' }}>
                        {pendingSkills.length > 0 && (
                          <button
                            type="button"
                            className="btn primary"
                            onClick={() => handleSelectSkillTab(pendingSkills[0])}
                            style={{ background: 'linear-gradient(135deg, var(--blue), var(--purple))' }}
                          >
                            Assess Next Skill: {pendingSkills[0]} →
                          </button>
                        )}
                        <button
                          type="button"
                          className="btn secondary"
                          onClick={handleRetakeAssessment}
                        >
                          Retake Assessment
                        </button>
                        <button
                          type="button"
                          className="btn secondary"
                          onClick={() => handleNavSubpage('gaps')}
                        >
                          View Skill Gap
                        </button>
                        <button
                          type="button"
                          className={pendingSkills.length > 0 ? 'btn secondary' : 'btn primary'}
                          onClick={() => handleNavSubpage('dashboard')}
                        >
                          View Dashboard
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* 10-Question Active Test View */
                    <div className="card">
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', borderBottom: '1px solid var(--line)', paddingBottom: '14px' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <h2 style={{ margin: 0 }}>
                              {activeAssessmentSkill} Assessment
                            </h2>
                            {assessmentScores[activeAssessmentSkill] && (
                              <span style={{ fontSize: '11px', background: '#e6f8ee', color: 'var(--green)', fontWeight: 700, padding: '2px 8px', borderRadius: '10px' }}>
                                Previously Completed ({assessmentScores[activeAssessmentSkill].percentage}%)
                              </span>
                            )}
                          </div>
                          <p className="muted small" style={{ margin: '4px 0 0' }}>
                            Single Quiz Progress • Answer all 10 questions to update this skill's verified rating.
                          </p>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <span style={{ fontWeight: 700, fontSize: '16px', color: 'var(--blue)' }}>
                            {Object.keys(selectedAnswers).length} / {currentQuestions.length}
                          </span>
                          <span className="muted small" style={{ display: 'block' }}>Questions Answered</span>
                        </div>
                      </div>

                      {/* Quiz questions answered progress indicator */}
                      <div
                        style={{
                          background: '#f1f3f9',
                          borderRadius: '8px',
                          height: '6px',
                          overflow: 'hidden',
                          marginBottom: '20px'
                        }}
                      >
                        <div
                          style={{
                            height: '100%',
                            width: `${(Object.keys(selectedAnswers).length / (currentQuestions.length || 1)) * 100}%`,
                            background: 'var(--blue)',
                            borderRadius: '8px',
                            transition: 'width 0.25s ease'
                          }}
                        />
                      </div>

                      {/* Error Banner */}
                      {assessmentError && (
                        <div
                          style={{
                            background: '#ffebe8',
                            color: '#d93838',
                            padding: '12px 16px',
                            borderRadius: '10px',
                            marginBottom: '18px',
                            fontWeight: 600,
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px'
                          }}
                        >
                          <span>⚠</span> {assessmentError}
                        </div>
                      )}

                      {/* 10 Questions Form */}
                      <form onSubmit={handleSubmitAssessment}>
                        {currentQuestions.map((q, idx) => {
                          const isAnswered = selectedAnswers[q.id] !== undefined;
                          return (
                            <div
                              key={q.id}
                              className="question-card"
                              style={{
                                borderColor: !isAnswered && assessmentError ? '#f8b4b4' : undefined
                              }}
                            >
                              <div className="question-title">
                                <span style={{ color: 'var(--blue)' }}>Q{idx + 1}.</span>
                                <span>{q.question}</span>
                              </div>

                              <div className="option-grid">
                                {q.options.map((opt, optIdx) => {
                                  const isSelected = selectedAnswers[q.id] === optIdx;
                                  const optLetter = String.fromCharCode(65 + optIdx); // A, B, C, D
                                  return (
                                    <button
                                      key={optIdx}
                                      type="button"
                                      className={`option-btn ${isSelected ? 'selected' : ''}`}
                                      onClick={() => handleSelectOption(q.id, optIdx)}
                                    >
                                      <span className="opt-indicator">{optLetter}</span>
                                      <span>{opt}</span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}

                        {/* Submission Actions */}
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '20px' }}>
                          <button
                            type="button"
                            className="btn secondary"
                            onClick={handleResetAnswers}
                          >
                            Reset Answers
                          </button>
                          <button
                            type="submit"
                            className="btn primary"
                          >
                            Submit Assessment →
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </div>
              )}

              {/* ----------------- SUBPAGE: SKILL GAPS ----------------- */}
              {currentSubpage === 'gaps' && (
                <div id="gapsPage">
                  <div className="card">
                    <h2>Skill Gap Analysis for {profile.career}</h2>
                    <p className="muted">
                      Comparison between your assessed skill levels and the target industry benchmarks for {profile.career}.
                    </p>

                    <div style={{ marginTop: '20px' }}>
                      {skillGaps.map(item => (
                        <div key={item.skill} style={{ marginBottom: '22px' }}>
                          <div className="rowlabel">
                            <span>
                              <b>{item.skill}</b>
                              <span style={{ marginLeft: '10px', fontSize: '12px' }}>
                                Student Level: <b>{item.currentLevel}%</b> • Required: <b>{item.requiredLevel}%</b>
                              </span>
                            </span>
                            <span>
                              {item.isMet ? (
                                <span style={{ color: 'var(--green)', fontWeight: 700 }}>Skill Met ✓</span>
                              ) : (
                                <span style={{ color: 'var(--red)', fontWeight: 700 }}>Gap: {item.gap}%</span>
                              )}
                            </span>
                          </div>
                          <div className="bar" style={{ position: 'relative' }}>
                            <i style={{ width: `${item.currentLevel}%` }}></i>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ borderTop: '1px solid var(--line)', paddingTop: '20px', marginTop: '25px' }}>
                      <h3>Personalized Recommendations & Learning Platforms</h3>
                      <p className="muted small">
                        Prioritized based on your lowest-scoring skills and largest identified gaps.
                      </p>

                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '15px', marginTop: '15px' }}>
                        {recommendedSkills.map(rec => (
                          <div
                            key={rec.skill}
                            style={{
                              background: '#fafbff',
                              border: '1px solid var(--line)',
                              borderRadius: '14px',
                              padding: '16px'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <h4 style={{ margin: 0, fontSize: '16px' }}>{rec.skill}</h4>
                              <span className={`tag ${rec.priority === 'High' ? 'tag-high' : rec.priority === 'Medium' ? 'tag-medium' : 'tag-low'}`}>
                                {rec.priority} Priority
                              </span>
                            </div>

                            <p className="small muted" style={{ margin: '8px 0' }}>
                              Current: <b>{rec.currentLevel}%</b> • Required: <b>{rec.requiredLevel}%</b> • Gap: <b style={{ color: 'var(--red)' }}>{rec.gap}%</b>
                            </p>

                            <div style={{ marginTop: '12px' }}>
                              <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--muted)', display: 'block', marginBottom: '6px' }}>
                                Recommended Platforms:
                              </span>
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                {rec.platforms.map(plat => (
                                  <a
                                    key={plat.name}
                                    href={plat.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="btn secondary"
                                    style={{ padding: '5px 10px', fontSize: '12px', textDecoration: 'none' }}
                                  >
                                    {plat.name} ↗
                                  </a>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: LEARNING ROADMAP ----------------- */}
              {currentSubpage === 'roadmap' && (
                <div id="roadmapPage">
                  <div className="card">
                    <h2>Personalized Learning Roadmap</h2>
                    <p className="muted">
                      Dynamically generated and sequenced according to your weakest assessed skills and career milestones.
                    </p>

                    <div className="timeline" style={{ marginTop: '25px' }}>
                      {dynamicRoadmapSteps.map((step, idx) => (
                        <React.Fragment key={idx}>
                          <div className="step">
                            <div>
                              <div className="dot"></div>
                            </div>
                            <div style={{ flex: 1 }}>
                              <p>{idx + 1}. {step.title}</p>
                              <small>{step.subtitle}</small>
                              <div style={{ marginTop: '4px' }}>
                                <span style={{ fontSize: '12px', color: 'var(--blue)', fontWeight: 600 }}>
                                  {step.status}
                                </span>
                              </div>
                            </div>
                          </div>
                          {idx < dynamicRoadmapSteps.length - 1 && <div className="line"></div>}
                        </React.Fragment>
                      ))}
                    </div>

                    <div style={{ marginTop: '30px', display: 'flex', gap: '12px' }}>
                      <button
                        type="button"
                        className="btn primary"
                        onClick={() => handleNavSubpage('assessment')}
                      >
                        Retake Skill Assessment
                      </button>
                      <button
                        type="button"
                        className="btn secondary"
                        onClick={() => handleNavSubpage('jobs')}
                      >
                        Explore Recommended Jobs
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: RECOMMENDED JOBS ----------------- */}
              {currentSubpage === 'jobs' && (
                <div id="jobsPage">
                  <h2>Recommended Jobs for {profile.career}</h2>
                  <p className="muted">
                    Skill match percentages are dynamically evaluated using your current assessed competencies.
                  </p>

                  <div className="jobs">
                    {dynamicJobs.map(job => (
                      <div key={job.id} className="card job">
                        <h3>{job.title}</h3>
                        <p className="muted small" style={{ margin: '2px 0 8px' }}>{job.company} • {job.location}</p>
                        <b style={{ color: 'var(--blue)', fontSize: '16px', display: 'block', margin: '6px 0' }}>
                          Skill Match: {job.computedMatch}%
                        </b>
                        <p>{job.requiredSkills.join(' • ')}</p>

                        {job.skillsToImprove.length > 0 && (
                          <div style={{ fontSize: '12px', color: 'var(--yellow)', margin: '6px 0 12px' }}>
                            ⚠ Need to improve: <b>{job.skillsToImprove.join(', ')}</b>
                          </div>
                        )}

                        <button
                          type="button"
                          className="btn secondary"
                          style={{ marginTop: 'auto' }}
                          onClick={() => setActiveJobModal(job)}
                        >
                          View Details
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: PROGRESS ----------------- */}
              {currentSubpage === 'progress' && (
                <div id="progressPage">
                  <h2>Progress Overview</h2>
                  <div className="card">
                    <h3>Overall Skill Progress</h3>
                    <p className="muted small">
                      Calculated from your verified skill assessments versus starting baseline and target.
                    </p>

                    <div className="rowlabel">
                      <span>Before Assessment</span>
                      <b>50%</b>
                    </div>
                    <div className="bar">
                      <i style={{ width: '50%' }}></i>
                    </div>

                    <div className="rowlabel">
                      <span>Current Assessed Skill Level</span>
                      <b style={{ color: 'var(--blue)' }}>{overallSkillMatch}%</b>
                    </div>
                    <div className="bar">
                      <i style={{ width: `${overallSkillMatch}%` }}></i>
                    </div>

                    <div className="rowlabel">
                      <span>Target Level</span>
                      <b>90%</b>
                    </div>
                    <div className="bar">
                      <i style={{ width: '90%' }}></i>
                    </div>

                    <h3 style={{ marginTop: '25px' }}>Improvement Over Time</h3>
                    <div className="chart">
                      <div className="column">
                        <i style={{ height: `${(50 / 100) * 160}px` }}></i>
                        Before (50%)
                      </div>
                      <div className="column">
                        <i style={{ height: `${(overallSkillMatch / 100) * 160}px` }}></i>
                        Current ({overallSkillMatch}%)
                      </div>
                      <div className="column">
                        <i style={{ height: `${(90 / 100) * 160}px` }}></i>
                        Target (90%)
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ----------------- SUBPAGE: PROFILE ----------------- */}
              {currentSubpage === 'profile2' && (
                <div id="profile2Page">
                  <div className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
                      <h2 style={{ margin: 0 }}>Student Profile</h2>
                      <button
                        type="button"
                        className="btn secondary"
                        onClick={() => handleNavigatePage('profile')}
                      >
                        Edit Profile
                      </button>
                    </div>

                    <p><b>Name:</b> <span>{profile.name}</span></p>
                    <p><b>Education:</b> <span>{profile.education}</span></p>
                    <p><b>Branch:</b> <span>{profile.branch}</span></p>
                    <p><b>Year:</b> <span>{profile.year}</span></p>
                    <p><b>Career Goal:</b> <span>{profile.career}</span></p>
                    <p><b>Skills:</b> <span>{profile.skills.join(', ')}</span></p>
                    <p><b>Resume:</b> <span>{profile.resume}</span></p>

                    <div style={{ marginTop: '20px', paddingTop: '15px', borderTop: '1px solid var(--line)' }}>
                      <h3>Assessment Summary</h3>
                      <p className="muted small">
                        Completed assessments: <b>{assessedCount}</b> of <b>{profile.skills.length}</b> skills.
                      </p>
                      <button
                        type="button"
                        className="btn primary"
                        onClick={() => handleNavSubpage('assessment')}
                      >
                        Go to Assessments →
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </main>
          </div>

          {/* ----------------- AI CAREER ASSISTANT ----------------- */}
          <div className="chat">
            {chatOpen && (
              <div className="chatbox">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--line)', paddingBottom: '8px', marginBottom: '10px' }}>
                  <b>AI Career Assistant</b>
                  <button
                    type="button"
                    onClick={() => setChatOpen(false)}
                    style={{ background: 'none', fontSize: '18px', color: 'var(--muted)', cursor: 'pointer' }}
                  >
                    ×
                  </button>
                </div>

                <div style={{ overflowY: 'auto', flex: 1, maxHeight: '220px', marginBottom: '10px' }}>
                  {chatHistory.map((msg, i) => (
                    <div
                      key={i}
                      style={{
                        margin: '6px 0',
                        padding: '8px 12px',
                        borderRadius: '10px',
                        fontSize: '13px',
                        lineHeight: '1.4',
                        background: msg.sender === 'user' ? '#eef2ff' : '#f5f7fc',
                        color: msg.sender === 'user' ? '#293a9c' : 'var(--text)',
                        alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start'
                      }}
                    >
                      <b>{msg.sender === 'user' ? 'You:' : 'AI:'}</b> {msg.text}
                    </div>
                  ))}
                </div>

                <p className="muted small" style={{ margin: '4px 0 6px' }}>Suggested questions:</p>
                <div className="q" onClick={() => handleAskAssistant('What skills should I learn next?')}>
                  What skills should I learn next?
                </div>
                <div className="q" onClick={() => handleAskAssistant(`How can I become a ${profile.career}?`)}>
                  How can I become a {profile.career}?
                </div>
                <div className="q" onClick={() => handleAskAssistant('Suggest a project.')}>
                  Suggest a project.
                </div>

                <div style={{ display: 'flex', gap: '6px', marginTop: '10px' }}>
                  <input
                    type="text"
                    placeholder="Ask any career or skill question..."
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAskAssistant(chatInput);
                      }
                    }}
                    style={{
                      flex: 1,
                      padding: '8px 10px',
                      borderRadius: '8px',
                      border: '1px solid var(--line)',
                      fontSize: '13px',
                      outline: 'none'
                    }}
                  />
                  <button
                    type="button"
                    className="btn primary"
                    style={{ padding: '8px 12px', fontSize: '13px' }}
                    onClick={() => handleAskAssistant(chatInput)}
                  >
                    Ask
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              className="chatbtn"
              onClick={() => setChatOpen(prev => !prev)}
            >
              💬 Ask AI Career Assistant
            </button>
          </div>

          {/* ----------------- MODALS ----------------- */}

          {/* Job Details Modal */}
          {activeJobModal && (
            <div className="modal-backdrop" onClick={() => setActiveJobModal(null)}>
              <div className="modal-box" onClick={e => e.stopPropagation()}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h3 style={{ margin: 0 }}>{activeJobModal.title}</h3>
                  <button
                    type="button"
                    onClick={() => setActiveJobModal(null)}
                    style={{ background: 'none', fontSize: '20px', cursor: 'pointer', color: 'var(--muted)' }}
                  >
                    ×
                  </button>
                </div>

                <p className="muted small" style={{ margin: '0 0 12px' }}>
                  {activeJobModal.company} • {activeJobModal.location}
                </p>

                <div style={{ background: '#f5f7fc', borderRadius: '12px', padding: '14px', marginBottom: '16px' }}>
                  <div style={{ fontSize: '14px', fontWeight: 700, marginBottom: '6px' }}>
                    Your Estimated Skill Match: <span style={{ color: 'var(--blue)' }}>{activeJobModal.computedMatch}%</span>
                  </div>
                  <div className="bar" style={{ margin: '6px 0 0' }}>
                    <i style={{ width: `${activeJobModal.computedMatch}%` }}></i>
                  </div>
                </div>

                <p style={{ fontSize: '14px', lineHeight: '1.6' }}>{activeJobModal.description}</p>

                <div style={{ marginTop: '16px' }}>
                  <b>Required Competencies:</b>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '8px' }}>
                    {activeJobModal.requiredSkills.map(sk => {
                      const { percentage } = getSkillPercentage(sk);
                      const isReady = percentage >= 70;
                      return (
                        <span
                          key={sk}
                          style={{
                            padding: '6px 12px',
                            borderRadius: '20px',
                            background: isReady ? '#eaf8f0' : '#fff2d9',
                            color: isReady ? '#107c41' : '#a06c0b',
                            fontSize: '13px',
                            fontWeight: 600
                          }}
                        >
                          {sk}: {percentage}% {isReady ? '✓ Ready' : '⚠ Needs improvement'}
                        </span>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '24px' }}>
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={() => setActiveJobModal(null)}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    className="btn primary"
                    onClick={() => {
                      alert(`Application submitted for ${activeJobModal.title} at ${activeJobModal.company}!`);
                      setActiveJobModal(null);
                    }}
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Project Details Modal */}
          {activeProjectModal && (
            <div className="modal-backdrop" onClick={() => setActiveProjectModal(false)}>
              <div className="modal-box" onClick={e => e.stopPropagation()}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h3 style={{ margin: 0 }}>Sales & Operations Analytics Dashboard</h3>
                  <button
                    type="button"
                    onClick={() => setActiveProjectModal(false)}
                    style={{ background: 'none', fontSize: '20px', cursor: 'pointer', color: 'var(--muted)' }}
                  >
                    ×
                  </button>
                </div>

                <p className="muted small" style={{ margin: '0 0 12px' }}>
                  Industry Capstone Project • Duration: ~6-8 hours
                </p>

                <p style={{ fontSize: '14px', lineHeight: '1.6' }}>
                  Build an executive dashboard analyzing retail customer retention, sales trajectories, and margin profitability across 4 global regions.
                </p>

                <div style={{ background: '#f5f7fc', borderRadius: '12px', padding: '14px', margin: '14px 0' }}>
                  <b>Project Deliverables:</b>
                  <ul style={{ margin: '8px 0 0', paddingLeft: '20px', fontSize: '13px', lineHeight: '1.7' }}>
                    <li>Clean and transform raw transactional data in SQL / Power Query</li>
                    <li>Calculate Customer Lifetime Value (CLV) and Churn Rate</li>
                    <li>Design interactive Power BI / Excel dashboards with slicers</li>
                    <li>Host project repo on GitHub with executive summary report</li>
                  </ul>
                </div>

                <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '20px' }}>
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={() => setActiveProjectModal(false)}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    className="btn primary"
                    onClick={() => {
                      window.open('https://github.com', '_blank', 'noopener,noreferrer');
                      setActiveProjectModal(false);
                    }}
                  >
                    Start Project Repo ↗
                  </button>
                </div>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
