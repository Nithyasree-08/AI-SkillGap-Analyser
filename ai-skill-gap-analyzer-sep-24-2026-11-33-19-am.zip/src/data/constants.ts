import { JobRecommendation, LearningPlatform, StudentProfile } from '../types';

export const DEFAULT_PROFILE: StudentProfile = {
  name: 'Nithya',
  education: 'B.Tech Computer Science',
  branch: 'Computer Science',
  year: '2nd Year',
  career: 'Data Analyst',
  skills: ['Python', 'Excel', 'SQL', 'Statistics', 'Power BI', 'Machine Learning'],
  resume: 'Not selected'
};

// Target benchmark requirements by career role
export const ROLE_SKILL_REQUIREMENTS: Record<string, Record<string, number>> = {
  'Data Analyst': {
    'Python': 85,
    'SQL': 85,
    'Excel': 80,
    'Statistics': 80,
    'Power BI': 80,
    'Machine Learning': 60,
    'Data Visualization': 75
  },
  'Software Developer': {
    'Python': 85,
    'SQL': 75,
    'JavaScript': 85,
    'Data Structures': 90,
    'Git': 80,
    'System Design': 70
  },
  'Data Scientist': {
    'Python': 90,
    'Statistics': 90,
    'Machine Learning': 85,
    'SQL': 80,
    'Data Visualization': 75,
    'Deep Learning': 70
  },
  'AI/ML Engineer': {
    'Python': 90,
    'Machine Learning': 90,
    'Deep Learning': 85,
    'Statistics': 85,
    'SQL': 70,
    'MLOps': 75
  },
  'Web Developer': {
    'JavaScript': 90,
    'HTML/CSS': 90,
    'React': 85,
    'Node.js': 80,
    'SQL': 70,
    'Git': 80
  },
  'Cybersecurity Analyst': {
    'Networking': 85,
    'Security Analysis': 85,
    'Linux': 80,
    'Python': 75,
    'SQL': 70,
    'Cryptography': 75
  }
};

export const SKILL_PLATFORMS: Record<string, LearningPlatform[]> = {
  'Power BI': [
    { name: 'Microsoft Learn', url: 'https://learn.microsoft.com/en-us/training/powerplatform/power-bi' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Power%20BI' },
    { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=power+bi+full+course' }
  ],
  'SQL': [
    { name: 'SQLBolt', url: 'https://sqlbolt.com/' },
    { name: 'W3Schools', url: 'https://www.w3schools.com/sql/' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=SQL' }
  ],
  'Advanced SQL': [
    { name: 'SQLBolt', url: 'https://sqlbolt.com/' },
    { name: 'LeetCode Database', url: 'https://leetcode.com/problemset/database/' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Advanced%20SQL' }
  ],
  'Python': [
    { name: 'Python.org', url: 'https://www.python.org/about/gettingstarted/' },
    { name: 'Kaggle', url: 'https://www.kaggle.com/learn/python' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Python' }
  ],
  'Excel': [
    { name: 'Microsoft Learn', url: 'https://learn.microsoft.com/en-us/office/' },
    { name: 'ExcelJet', url: 'https://exceljet.net/' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Excel' }
  ],
  'Statistics': [
    { name: 'Khan Academy', url: 'https://www.khanacademy.org/math/statistics-probability' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Statistics' },
    { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=statistics+for+data+science' }
  ],
  'Machine Learning': [
    { name: 'Coursera', url: 'https://www.coursera.org/learn/machine-learning' },
    { name: 'Kaggle Learn', url: 'https://www.kaggle.com/learn' },
    { name: 'Fast.ai', url: 'https://www.fast.ai/' }
  ],
  'Data Visualization': [
    { name: 'Tableau Public', url: 'https://public.tableau.com/' },
    { name: 'FreeCodeCamp', url: 'https://www.freecodecamp.org/' },
    { name: 'Coursera', url: 'https://www.coursera.org/search?query=Data%20Visualization' }
  ]
};

export const DEFAULT_PLATFORMS: LearningPlatform[] = [
  { name: 'Coursera', url: 'https://www.coursera.org' },
  { name: 'edX', url: 'https://www.edx.org' },
  { name: 'YouTube', url: 'https://www.youtube.com' }
];

export const INITIAL_JOBS: JobRecommendation[] = [
  {
    id: 'job-1',
    title: 'Data Analyst',
    company: 'Apex Data Insights',
    location: 'Remote / Hybrid',
    requiredSkills: ['Python', 'SQL', 'Excel', 'Power BI'],
    description: 'Transform complex enterprise business datasets into executive dashboards, automated pipelines, and actionable stakeholder metrics.'
  },
  {
    id: 'job-2',
    title: 'Junior Data Analyst',
    company: 'NextGen Analytics',
    location: 'Bangalore, IN / Hybrid',
    requiredSkills: ['Excel', 'SQL', 'Data Visualization'],
    description: 'Collaborate with marketing and product squads to validate metrics, extract SQL queries, and prepare weekly reports.'
  },
  {
    id: 'job-3',
    title: 'Business Analyst',
    company: 'Cognitive Solutions',
    location: 'Mumbai, IN / On-site',
    requiredSkills: ['Excel', 'SQL', 'Statistics'],
    description: 'Translate operational data and customer feedback into requirement documents, statistical models, and KPI trackers.'
  },
  {
    id: 'job-4',
    title: 'Associate BI Developer',
    company: 'Insight Dynamics',
    location: 'Remote',
    requiredSkills: ['Power BI', 'SQL', 'Excel'],
    description: 'Develop and maintain enterprise Power BI models, DAX measures, and real-time visualization dashboards.'
  }
];
