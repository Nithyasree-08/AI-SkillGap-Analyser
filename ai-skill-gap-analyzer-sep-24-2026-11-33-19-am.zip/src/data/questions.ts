import { Question } from '../types';

export const SKILL_QUESTIONS: Record<string, Question[]> = {
  Python: [
    {
      id: 1,
      question: 'Which built-in Python data structure is mutable and maintains insertion order?',
      options: ['Tuple', 'List', 'FrozenSet', 'String'],
      correctIndex: 1,
      explanation: 'Lists are mutable ordered sequences in Python.'
    },
    {
      id: 2,
      question: 'What is the correct syntax for a list comprehension generating squares of even numbers from 0 to 8?',
      options: [
        '[x**2 for x in range(10) if x % 2 == 0]',
        '[x**2 if x % 2 == 0 for x in range(10)]',
        '[for x in range(10): x**2 if x % 2 == 0]',
        '{x**2 : x in range(10) if x % 2 == 0}'
      ],
      correctIndex: 0,
      explanation: 'The standard list comprehension syntax places the if condition after the for loop.'
    },
    {
      id: 3,
      question: 'In Pandas, which method is typically used to inspect the summary statistics of numeric columns?',
      options: ['df.summary()', 'df.describe()', 'df.info_stats()', 'df.values()'],
      correctIndex: 1,
      explanation: '`df.describe()` generates descriptive statistics such as count, mean, std, and quantiles.'
    },
    {
      id: 4,
      question: 'What is the key difference between `is` and `==` in Python?',
      options: [
        '`is` checks memory identity, while `==` checks value equality',
        '`is` is for numbers, `==` is for strings',
        '`==` checks identity, `is` checks data types',
        'There is no difference, both are aliases'
      ],
      correctIndex: 0,
      explanation: '`is` tests object identity (memory address), while `==` tests value equivalence.'
    },
    {
      id: 5,
      question: 'What does the `*args` syntax in a Python function definition represent?',
      options: [
        'A pointer to variable memory',
        'Arbitrary positional arguments bundled into a tuple',
        'Keyword arguments stored in a dictionary',
        'A mandatory list of parameters'
      ],
      correctIndex: 1,
      explanation: '`*args` allows passing a variable number of positional arguments as a tuple.'
    },
    {
      id: 6,
      question: 'Which method in Pandas allows removing rows with missing (NaN) values?',
      options: ['df.clean_null()', 'df.dropna()', 'df.fill_null()', 'df.remove_nan()'],
      correctIndex: 1,
      explanation: '`df.dropna()` drops rows or columns containing missing values.'
    },
    {
      id: 7,
      question: 'What is the purpose of the `yield` keyword in a Python function?',
      options: [
        'Terminates function execution immediately',
        'Turns the function into a generator that yields values one at a time',
        'Imports an external asynchronous module',
        'Throws a runtime exception'
      ],
      correctIndex: 1,
      explanation: '`yield` suspends function state and yields control, creating a generator.'
    },
    {
      id: 8,
      question: 'How do you handle potential runtime exceptions gracefully in Python?',
      options: [
        'try ... except ... finally blocks',
        'catch ... throw blocks',
        'guard ... rescue blocks',
        'test ... error blocks'
      ],
      correctIndex: 0,
      explanation: 'Python uses `try`, `except`, `else`, and `finally` for structured exception handling.'
    },
    {
      id: 9,
      question: 'In Python, what is the default time complexity of looking up a key in a dictionary?',
      options: ['O(n)', 'O(log n)', 'O(1) average', 'O(n^2)'],
      correctIndex: 2,
      explanation: 'Dictionaries are hash tables with O(1) average case lookup time complexity.'
    },
    {
      id: 10,
      question: 'Which module in Python is used for executing regular expressions?',
      options: ['regex_py', 're', 'pattern', 'textmatch'],
      correctIndex: 1,
      explanation: 'The standard module for regular expressions in Python is `re`.'
    }
  ],

  SQL: [
    {
      id: 1,
      question: 'Which SQL clause is used to filter records after aggregate functions (like GROUP BY)?',
      options: ['WHERE', 'HAVING', 'FILTER', 'AGGREGATE'],
      correctIndex: 1,
      explanation: 'HAVING filters groups created by GROUP BY, whereas WHERE filters individual rows before grouping.'
    },
    {
      id: 2,
      question: 'What is the result of a LEFT JOIN between Table A and Table B?',
      options: [
        'All rows from Table A, plus matching rows from Table B',
        'Only rows where keys match in both tables',
        'All rows from Table B, plus matching rows from Table A',
        'A cartesian product of Table A and Table B'
      ],
      correctIndex: 0,
      explanation: 'LEFT JOIN returns all records from the left table and matched records from the right table.'
    },
    {
      id: 3,
      question: 'Which SQL window function computes a row rank without leaving gaps for duplicate values?',
      options: ['RANK()', 'DENSE_RANK()', 'ROW_NUMBER()', 'NTILE()'],
      correctIndex: 1,
      explanation: 'DENSE_RANK() assigns consecutive rankings without gaps when ties occur.'
    },
    {
      id: 4,
      question: 'How do you eliminate duplicate rows from a SQL query result?',
      options: ['SELECT UNIQUE', 'SELECT DISTINCT', 'SELECT NO_DUPLICATES', 'SELECT ISOLATED'],
      correctIndex: 1,
      explanation: '`SELECT DISTINCT` returns only distinct (different) values.'
    },
    {
      id: 5,
      question: 'Which constraint ensures that all values in a column are distinct and not null?',
      options: ['CHECK', 'FOREIGN KEY', 'PRIMARY KEY', 'DEFAULT'],
      correctIndex: 2,
      explanation: 'A PRIMARY KEY uniquely identifies each record and cannot contain NULL values.'
    },
    {
      id: 6,
      question: 'What does the SQL statement `COALESCE(val1, val2, val3)` return?',
      options: [
        'The highest numeric value among arguments',
        'The first non-null expression in the argument list',
        'A concatenated string of all values',
        'The count of non-null arguments'
      ],
      correctIndex: 1,
      explanation: 'COALESCE returns the first non-null argument evaluated from left to right.'
    },
    {
      id: 7,
      question: 'Which clause is used to sort the result-set in descending order?',
      options: ['SORT BY col DESC', 'ORDER BY col DESC', 'GROUP BY col DESC', 'ARRANGE BY col DESC'],
      correctIndex: 1,
      explanation: 'ORDER BY column_name DESC sorts query outputs descending.'
    },
    {
      id: 8,
      question: 'What is a Common Table Expression (CTE) defined with in SQL?',
      options: ['USING clause', 'WITH clause', 'LET clause', 'DECLARE clause'],
      correctIndex: 1,
      explanation: 'CTEs are defined using the `WITH cte_name AS (...)` syntax.'
    },
    {
      id: 9,
      question: 'Which operator is used to test for a match against a wildcard pattern in SQL?',
      options: ['MATCH', 'LIKE', 'IN', 'EXISTS'],
      correctIndex: 1,
      explanation: '`LIKE` is used with `%` and `_` wildcards for pattern matching.'
    },
    {
      id: 10,
      question: 'What is the main purpose of creating an index on a database table column?',
      options: [
        'To speed up data retrieval operations',
        'To compress database file size on disk',
        'To prevent null values from being entered',
        'To encrypt sensitive user data'
      ],
      correctIndex: 0,
      explanation: 'Indexes significantly increase search and retrieval query performance.'
    }
  ],

  Excel: [
    {
      id: 1,
      question: 'Which modern Excel function replaces both VLOOKUP and HLOOKUP with greater flexibility?',
      options: ['INDEX_MATCH', 'XLOOKUP', 'QUICKLOOK', 'SMARTFIND'],
      correctIndex: 1,
      explanation: 'XLOOKUP can search in any direction and handles defaults without requiring left-to-right tables.'
    },
    {
      id: 2,
      question: 'What does the `$` sign represent in a cell reference like `$A$1` in Excel?',
      options: [
        'Currency formatting mode',
        'Absolute cell reference (locks column and row when copied)',
        'Reference to an external workbook',
        'Dynamic array pointer'
      ],
      correctIndex: 1,
      explanation: '`$` locks the column and row coordinate, preventing it from changing when dragged.'
    },
    {
      id: 3,
      question: 'Which tool in Excel allows you to summarize, analyze, explore, and present summary data interactively?',
      options: ['Data Validation', 'Pivot Table', 'Solver', 'Goal Seek'],
      correctIndex: 1,
      explanation: 'Pivot Tables enable fast aggregations, slicing, and interactive data analysis.'
    },
    {
      id: 4,
      question: 'What is the purpose of the `COUNTIF` function in Excel?',
      options: [
        'Counts cells in a range that meet a single specific condition',
        'Sums numbers matching a condition',
        'Averages only positive numbers',
        'Counts unique blank cells'
      ],
      correctIndex: 0,
      explanation: 'COUNTIF counts the number of cells that meet a given criterion.'
    },
    {
      id: 5,
      question: 'Which formula correctly checks if cell A1 is greater than 50, returning "Pass" or "Fail"?',
      options: [
        '=CHECK(A1 > 50, "Pass", "Fail")',
        '=IF(A1 > 50, "Pass", "Fail")',
        '=IIF(A1 > 50: "Pass": "Fail")',
        '=WHERE(A1 > 50, "Pass", "Fail")'
      ],
      correctIndex: 1,
      explanation: '`=IF(logical_test, value_if_true, value_if_false)` is the standard syntax.'
    },
    {
      id: 6,
      question: 'In Power Query for Excel, what data transformation language is used behind the scenes?',
      options: ['VBA', 'M code', 'SQL', 'DAX'],
      correctIndex: 1,
      explanation: 'Power Query uses the functional M language for ETL data transformations.'
    },
    {
      id: 7,
      question: 'What Excel feature automatically highlights cells that meet specific criteria (such as values > 100)?',
      options: ['Data Validation', 'Conditional Formatting', 'Filter View', 'Flash Fill'],
      correctIndex: 1,
      explanation: 'Conditional Formatting changes cell appearance based on cell values or formula rules.'
    },
    {
      id: 8,
      question: 'Which formula combination is historically used when a lookup column is to the right of the return column?',
      options: ['VLOOKUP + HLOOKUP', 'INDEX + MATCH', 'FIND + SEARCH', 'OFFSET + SUM'],
      correctIndex: 1,
      explanation: 'INDEX/MATCH can look up values in any column irrespective of order.'
    },
    {
      id: 9,
      question: 'What does the `#N/A` error in Excel typically indicate?',
      options: [
        'Division by zero',
        'A value is not available or not found by a lookup function',
        'Invalid formula syntax or name typo',
        'The cell is too narrow to display text'
      ],
      correctIndex: 1,
      explanation: '#N/A means "no value available", standard when a lookup query fails to locate a match.'
    },
    {
      id: 10,
      question: 'Which Excel feature can automatically detect patterns in data entry and fill remaining rows?',
      options: ['AutoFormat', 'Flash Fill', 'Power Pivot', 'Scenario Manager'],
      correctIndex: 1,
      explanation: 'Flash Fill (Ctrl+E) senses patterns in adjacent columns to fill data automatically.'
    }
  ],

  Statistics: [
    {
      id: 1,
      question: 'Which measure of central tendency is least sensitive to extreme outliers?',
      options: ['Mean', 'Median', 'Standard Deviation', 'Variance'],
      correctIndex: 1,
      explanation: 'The median represents the middle value and remains robust against skewed outliers.'
    },
    {
      id: 2,
      question: 'In hypothesis testing, what is a Type I error?',
      options: [
        'Rejecting a true null hypothesis (False Positive)',
        'Failing to reject a false null hypothesis (False Negative)',
        'Calculating the wrong test statistic',
        'Using a sample size that is too large'
      ],
      correctIndex: 0,
      explanation: 'Type I error occurs when the null hypothesis is true but is rejected (alpha level).'
    },
    {
      id: 3,
      question: 'What does a p-value less than 0.05 generally indicate in statistical testing?',
      options: [
        'The null hypothesis is proven 100% true',
        'Statistically significant evidence to reject the null hypothesis at the 5% level',
        'The test has low statistical power',
        'The sample size must be doubled'
      ],
      correctIndex: 1,
      explanation: 'A p-value < 0.05 means observed data would be very unlikely under the null hypothesis.'
    },
    {
      id: 4,
      question: 'What does the standard deviation measure in a dataset?',
      options: [
        'The difference between maximum and minimum values',
        'The dispersion or spread of values around the mean',
        'The most frequent category',
        'The correlation between two variables'
      ],
      correctIndex: 1,
      explanation: 'Standard deviation quantifies the amount of variation or dispersion around the mean.'
    },
    {
      id: 5,
      question: 'According to the Central Limit Theorem, what distribution does the sample mean approximate as sample size increases?',
      options: ['Uniform distribution', 'Normal distribution', 'Poisson distribution', 'Exponential distribution'],
      correctIndex: 1,
      explanation: 'The sample mean distribution tends toward a normal distribution as sample size n grows large.'
    },
    {
      id: 6,
      question: 'What range of values can Pearson’s correlation coefficient (r) take?',
      options: ['0 to 1', '-1 to +1', '-100 to +100', '0 to infinity'],
      correctIndex: 1,
      explanation: 'Pearson correlation ranges from -1 (perfect negative) to +1 (perfect positive correlation).'
    },
    {
      id: 7,
      question: 'In a standard normal distribution, approximately what percentage of data falls within 1 standard deviation of the mean?',
      options: ['50%', '68%', '95%', '99.7%'],
      correctIndex: 1,
      explanation: 'Under the 68-95-99.7 rule, about 68% of data falls within 1 standard deviation of the mean.'
    },
    {
      id: 8,
      question: 'What statistical test is commonly used to compare the means of two independent groups?',
      options: ['Chi-Square test of independence', 'Two-sample Independent t-test', 'ANOVA test', 'Kruskal-Wallis test'],
      correctIndex: 1,
      explanation: 'The independent two-sample t-test compares the means of two unrelated groups.'
    },
    {
      id: 9,
      question: 'What does the Interquartile Range (IQR) represent?',
      options: [
        'Difference between Q3 (75th percentile) and Q1 (25th percentile)',
        'Average of minimum and maximum values',
        'The square root of variance',
        'Sum of all quartiles divided by 4'
      ],
      correctIndex: 0,
      explanation: 'IQR = Q3 - Q1, spanning the middle 50% of the dataset.'
    },
    {
      id: 10,
      question: 'Which principle states that correlation does NOT imply causality?',
      options: [
        'Ockham’s Razor',
        'Spurious Correlation principle',
        'Law of Large Numbers',
        'Bayes’ Theorem'
      ],
      correctIndex: 1,
      explanation: 'Two correlated variables may simply share a confounding factor without direct causation.'
    }
  ],

  'Power BI': [
    {
      id: 1,
      question: 'Which formula expression language is used to create calculated columns and measures in Power BI?',
      options: ['M', 'DAX', 'SQL', 'Python'],
      correctIndex: 1,
      explanation: 'DAX (Data Analysis Expressions) is used for calculations and measures in Power BI.'
    },
    {
      id: 2,
      question: 'What is the main difference between a Calculated Column and a Measure in Power BI?',
      options: [
        'Calculated columns are evaluated row-by-row and stored in memory; measures are computed dynamically upon visual aggregation',
        'Measures use M language, calculated columns use DAX',
        'Calculated columns cannot use numbers',
        'There is no difference in memory or execution'
      ],
      correctIndex: 0,
      explanation: 'Measures evaluate on-the-fly depending on filter context, saving memory.'
    },
    {
      id: 3,
      question: 'Which component of Power BI is used for data ingestion, cleaning, and ETL transformations?',
      options: ['Power Pivot', 'Power Query Editor', 'Power View', 'Power Automate'],
      correctIndex: 1,
      explanation: 'Power Query Editor is the ETL engine in Power BI desktop.'
    },
    {
      id: 4,
      question: 'Which DAX function is crucial for modifying or overriding the current filter context in a calculation?',
      options: ['SUM()', 'CALCULATE()', 'LOOKUPVALUE()', 'RELATED()'],
      correctIndex: 1,
      explanation: '`CALCULATE()` evaluates an expression in a modified filter context.'
    },
    {
      id: 5,
      question: 'What is the ideal schema design for optimal performance in Power BI data modeling?',
      options: ['Flat Single-Table Schema', 'Star Schema', 'Deeply nested Snowflake Schema with 10 levels', 'Graph database schema'],
      correctIndex: 1,
      explanation: 'Star schemas (Fact tables connected directly to Dimension tables) are best for Power BI.'
    },
    {
      id: 6,
      question: 'What visual element allows end-users to interactively filter report pages by date, category, or region?',
      options: ['Slicer', 'Card visual', 'Gauge chart', 'Matrix header'],
      correctIndex: 0,
      explanation: 'A Slicer visual provides interactive on-canvas filtering for users.'
    },
    {
      id: 7,
      question: 'Which connectivity mode queries data source tables directly without importing data into memory?',
      options: ['Import Mode', 'DirectQuery Mode', 'Dual Mode', 'Push Dataset'],
      correctIndex: 1,
      explanation: 'DirectQuery sends native queries to underlying databases at visual runtime.'
    },
    {
      id: 8,
      question: 'What function does `RELATED()` perform in DAX?',
      options: [
        'Fetches a related value from another table connected by an active relationship',
        'Merges two queries in Power Query',
        'Finds synonymous column headers',
        'Creates a foreign key constraint'
      ],
      correctIndex: 0,
      explanation: '`RELATED(column)` returns a related value from the "one" side of a relationship.'
    },
    {
      id: 9,
      question: 'What is Row-Level Security (RLS) used for in Power BI?',
      options: [
        'Encrypting the .pbix file on local disk',
        'Restricting data access for given users based on filters defined by roles',
        'Limiting the number of rows a visual can render',
        'Preventing unauthorized SQL injections'
      ],
      correctIndex: 1,
      explanation: 'RLS restricts row access based on user credentials and assigned DAX filter roles.'
    },
    {
      id: 10,
      question: 'Where can published Power BI reports be shared, scheduled for automatic data refresh, and embedded into dashboards?',
      options: ['Power BI Desktop', 'Power BI Service (Cloud)', 'Power BI Report Builder only', 'Azure Active Directory'],
      correctIndex: 1,
      explanation: 'Power BI Service is the SaaS cloud portal for publishing, sharing, and scheduled refreshes.'
    }
  ],

  'Machine Learning': [
    {
      id: 1,
      question: 'What is the primary difference between Supervised and Unsupervised Learning?',
      options: [
        'Supervised learning uses labeled training data, while unsupervised learning discovers patterns in unlabeled data',
        'Supervised learning requires GPU hardware, while unsupervised does not',
        'Unsupervised learning is only used for image classification',
        'Supervised models cannot make predictions'
      ],
      correctIndex: 0,
      explanation: 'Supervised learning trains on known input-output pairs; unsupervised finds intrinsic structure in unlabeled data.'
    },
    {
      id: 2,
      question: 'What common problem occurs when a model performs exceptionally well on training data but poorly on unseen test data?',
      options: ['Underfitting', 'Overfitting', 'High bias', 'Data sparsity'],
      correctIndex: 1,
      explanation: 'Overfitting occurs when a model memorizes noise and fails to generalize to unseen test data.'
    },
    {
      id: 3,
      question: 'Which metric is best suited for evaluating a classification model on an imbalanced dataset?',
      options: ['Raw Accuracy', 'Precision, Recall, and F1-Score', 'Mean Squared Error', 'R-squared'],
      correctIndex: 1,
      explanation: 'F1-score balances Precision and Recall, avoiding accuracy paradox in imbalanced classes.'
    },
    {
      id: 4,
      question: 'What technique helps prevent overfitting by penalizing large model coefficients in linear regression?',
      options: ['Regularization (L1 Lasso / L2 Ridge)', 'One-Hot Encoding', 'Principal Component Analysis', 'K-Means'],
      correctIndex: 0,
      explanation: 'L1 and L2 regularization penalize weight magnitude, simplifying the hypothesis.'
    },
    {
      id: 5,
      question: 'Which algorithm is an ensemble method combining multiple decision trees using bootstrap aggregation?',
      options: ['Support Vector Machine', 'Random Forest', 'K-Nearest Neighbors', 'Naive Bayes'],
      correctIndex: 1,
      explanation: 'Random Forest builds an ensemble of decorrelated decision trees using bagging.'
    },
    {
      id: 6,
      question: 'What is the purpose of cross-validation (e.g., 5-fold CV)?',
      options: [
        'To clean missing data automatically',
        'To assess how model results generalize to an independent dataset and detect overfitting',
        'To increase the size of the training dataset',
        'To encrypt weights during training'
      ],
      correctIndex: 1,
      explanation: 'K-fold cross-validation evaluates model stability across multiple data splits.'
    },
    {
      id: 7,
      question: 'Which algorithm is commonly used for unsupervised clustering of data points into k groups?',
      options: ['Linear Regression', 'Logistic Regression', 'K-Means Clustering', 'Decision Tree Classifier'],
      correctIndex: 2,
      explanation: 'K-Means partitions observations into k clusters around calculated centroids.'
    },
    {
      id: 8,
      question: 'What does the ROC-AUC curve evaluate in binary classification?',
      options: [
        'Training execution speed versus RAM usage',
        'Trade-off between True Positive Rate and False Positive Rate across all thresholds',
        'Loss function convergence over training epochs',
        'Feature correlation matrix'
      ],
      correctIndex: 1,
      explanation: 'ROC-AUC measures classification capability across various discrimination thresholds.'
    },
    {
      id: 9,
      question: 'Why is feature scaling (like StandardScaler or MinMaxScaler) important for algorithms like KNN and SVM?',
      options: [
        'Because they rely on geometric Euclidean distance calculations between feature values',
        'Because it converts categorical text into numbers',
        'Because without scaling the computer crashes',
        'Because trees cannot split unscaled data'
      ],
      correctIndex: 0,
      explanation: 'Distance-based algorithms give undue weight to features with larger numeric scales.'
    },
    {
      id: 10,
      question: 'What popular Python library is standard for classical machine learning algorithms and preprocessing?',
      options: ['Scikit-Learn', 'PyTorch', 'Django', 'Requests'],
      correctIndex: 0,
      explanation: 'Scikit-Learn (`sklearn`) is the cornerstone library for classical machine learning in Python.'
    }
  ],

  'Data Visualization': [
    {
      id: 1,
      question: 'Which chart type is most effective for displaying the distribution and spread of continuous numerical data?',
      options: ['Pie Chart', 'Box Plot / Histogram', 'Donut Chart', 'Treemap'],
      correctIndex: 1,
      explanation: 'Histograms and box plots clearly show data distributions, medians, and skewness.'
    },
    {
      id: 2,
      question: 'Why are 3D pie charts generally discouraged in professional data visualization?',
      options: [
        'They distort proportions and make accurate visual comparison of angles difficult',
        'They take too much computer memory to render',
        'Color blind users cannot see 3D',
        'They only work in Microsoft Excel'
      ],
      correctIndex: 0,
      explanation: 'Perspective tilt distorts slice areas and angles, leading to misleading interpretations.'
    },
    {
      id: 3,
      question: 'Which Python visualization library is built on Matplotlib and offers high-level statistical plotting themes?',
      options: ['Seaborn', 'Flask', 'NumPy', 'SymPy'],
      correctIndex: 0,
      explanation: 'Seaborn provides beautiful default themes and statistical aggregation plots.'
    },
    {
      id: 4,
      question: 'What visual attribute is most easily perceived pre-attentively by human vision?',
      options: ['Length and position on a common scale', 'Hue shading variations', 'Area of 3D bubbles', 'Curvature'],
      correctIndex: 0,
      explanation: 'Position along a common aligned scale has the highest human perceptual accuracy.'
    },
    {
      id: 5,
      question: 'What chart type should be preferred when visualizing a continuous trend over time (e.g., monthly sales)?',
      options: ['Line Chart', 'Radar Chart', 'Pie Chart', 'Funnel Chart'],
      correctIndex: 0,
      explanation: 'Line charts are the gold standard for continuous time-series trend tracking.'
    },
    {
      id: 6,
      question: 'In interactive dashboard design, what is "Drill-Down"?',
      options: [
        'Moving from high-level summary data to more granular detail by clicking a visual element',
        'Deleting outdated rows from a database table',
        'Exporting raw unformatted CSVs',
        'Rotating a chart 90 degrees'
      ],
      correctIndex: 0,
      explanation: 'Drill-down navigates from summary levels (e.g. Year) to granular levels (e.g. Month, Day).'
    },
    {
      id: 7,
      question: 'Which Javascript charting library is renowned for custom, data-driven SVG manipulations on the web?',
      options: ['D3.js', 'jQuery', 'Angular', 'Babel'],
      correctIndex: 0,
      explanation: 'D3.js (Data-Driven Documents) is the benchmark standard for web data visualization.'
    },
    {
      id: 8,
      question: 'What is a Heatmap primarily used to visualize?',
      options: [
        'Matrix correlation or 2D density using color gradations',
        'Network server CPU temperature exclusively',
        'Single scalar KPIs',
        'Audio waveforms'
      ],
      correctIndex: 0,
      explanation: 'Heatmaps represent values in a matrix format using sequential color gradients.'
    },
    {
      id: 9,
      question: 'What is the Data-to-Ink ratio concept popularized by Edward Tufte?',
      options: [
        'The proportion of graphic ink devoted to non-redundant core data information',
        'The amount of physical ink needed to print a chart',
        'The ratio of text labels to bar heights',
        'The number of colors used in a dashboard'
      ],
      correctIndex: 0,
      explanation: 'Tufte argued for maximizing data-ink by removing chart junk and non-essential visual clutter.'
    },
    {
      id: 10,
      question: 'When designing charts for accessibility, why should you avoid using only red and green to denote status?',
      options: [
        'Red-green color blindness is the most common form of color deficiency',
        'Red and green pixels burn out monitors faster',
        'Printers cannot reproduce green accurately',
        'Red and green are reserved for traffic lights only'
      ],
      correctIndex: 0,
      explanation: 'Color-blind users may not distinguish red from green; pairing colors with icons/labels is essential.'
    }
  ]
};

export function getQuestionsForSkill(skillName: string): Question[] {
  const normalized = skillName.trim();
  // Case-insensitive lookup
  const match = Object.keys(SKILL_QUESTIONS).find(
    k => k.toLowerCase() === normalized.toLowerCase()
  );
  if (match && SKILL_QUESTIONS[match]) {
    return SKILL_QUESTIONS[match];
  }

  // Generates 10 high quality standardized questions tailored to any custom skill
  return [
    {
      id: 1,
      question: `What is the fundamental core concept of ${normalized}?`,
      options: [
        `Syntax, fundamentals, and modular architecture`,
        `Hardware CPU register manipulation only`,
        `Static documentation without implementation`,
        `Unrelated legacy mainframe protocols`
      ],
      correctIndex: 0,
      explanation: `Core competency requires understanding architecture and foundational mechanics.`
    },
    {
      id: 2,
      question: `Which best practice is recommended for error handling and validation in ${normalized}?`,
      options: [
        `Ignoring edge cases and relying on client defaults`,
        `Structured exception handling, defensive checks, and informative logging`,
        `Suppressing all runtime warnings silently`,
        `Restarting the application process on each error`
      ],
      correctIndex: 1,
      explanation: `Defensive validation and structured logging ensure production stability.`
    },
    {
      id: 3,
      question: `How is performance optimization typically achieved in ${normalized}?`,
      options: [
        `Adding arbitrary delays to operations`,
        `Profiling bottlenecks, optimizing algorithms, and caching repeated calculations`,
        `Increasing hardware clock speed without code improvements`,
        `Removing comments and whitespace from source code only`
      ],
      correctIndex: 1,
      explanation: `Profiling and algorithmic efficiency are key to performance tuning.`
    },
    {
      id: 4,
      question: `In professional engineering, what tool is primarily used for version control with ${normalized}?`,
      options: [
        `Git and remote repositories`,
        `Local file rename copies (e.g. final_v2.txt)`,
        `USB flash drive backups`,
        `Emailing zip attachments`
      ],
      correctIndex: 0,
      explanation: `Git is the industry standard distributed version control system.`
    },
    {
      id: 5,
      question: `When writing tests for ${normalized} projects, which testing methodology checks individual components in isolation?`,
      options: [
        `Unit Testing`,
        `User Acceptance Testing`,
        `Stress and Load Testing`,
        `Manual exploratory testing only`
      ],
      correctIndex: 0,
      explanation: `Unit testing tests isolated functions and logic units.`
    },
    {
      id: 6,
      question: `Which data structure in ${normalized} is best suited for fast key-value lookups?`,
      options: [
        `Hash Map / Dictionary`,
        `Linked List`,
        `Linear Array`,
        `Stack`
      ],
      correctIndex: 0,
      explanation: `Hash structures offer O(1) average lookup time.`
    },
    {
      id: 7,
      question: `What security consideration should always be prioritized when working with ${normalized}?`,
      options: [
        `Hardcoding database passwords in client files`,
        `Sanitizing inputs to prevent injection vulnerabilities and maintaining least privilege access`,
        `Disabling SSL certificates for faster responses`,
        `Using plaintext HTTP for internal endpoints`
      ],
      correctIndex: 1,
      explanation: `Input sanitization and least privilege prevent major security exploits.`
    },
    {
      id: 8,
      question: `How are dependencies and external libraries typically managed in ${normalized}?`,
      options: [
        `Using standard package managers with semantic lockfiles`,
        `Copying code manually from forum posts`,
        `Compiling the operating system kernel`,
        `Writing all libraries from scratch`
      ],
      correctIndex: 0,
      explanation: `Package managers maintain reproducible dependencies across team environments.`
    },
    {
      id: 9,
      question: `Which design pattern in ${normalized} separates data access logic from business rules?`,
      options: [
        `Repository / Data Access Object (DAO) Pattern`,
        `God Object Pattern`,
        `Spaghetti Code Pattern`,
        `Tight Coupling Pattern`
      ],
      correctIndex: 0,
      explanation: `Repository patterns cleanly isolate persistence details from domain logic.`
    },
    {
      id: 10,
      question: `What is the industry standard for continuous integration (CI) and deployment of ${normalized} solutions?`,
      options: [
        `Automated pipelines executing tests, builds, and linting on code push`,
        `Manual FTP file uploads directly to live production servers`,
        `Publishing only once per calendar year`,
        `Testing code directly in live customer environments`
      ],
      correctIndex: 0,
      explanation: `Automated CI/CD pipelines guarantee code quality and dependable deployments.`
    }
  ];
}
