export interface Question {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

export interface SkillScore {
  skill: string;
  correctAnswers: number;
  totalQuestions: number;
  percentage: number;
  status: 'Strong' | 'Needs Improvement' | 'Needs More Practice';
  completedAt: string;
}

export interface StudentProfile {
  name: string;
  education: string;
  branch: string;
  year: string;
  career: string;
  skills: string[];
  resume: string;
}

export interface SkillGapItem {
  skill: string;
  currentLevel: number;
  requiredLevel: number;
  gap: number;
  isMet: boolean;
  priority: 'High' | 'Medium' | 'Low' | 'Completed';
  category: 'Strong' | 'Needs Improvement' | 'Needs More Practice';
}

export interface LearningPlatform {
  name: string;
  url: string;
}

export interface RecommendedSkillInfo {
  skill: string;
  currentLevel: number;
  requiredLevel: number;
  gap: number;
  priority: 'High' | 'Medium' | 'Low';
  platforms: LearningPlatform[];
}

export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  requiredSkills: string[];
  description: string;
  computedMatch?: number;
  skillsToImprove?: string[];
}
