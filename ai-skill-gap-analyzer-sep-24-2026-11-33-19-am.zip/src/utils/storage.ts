import { StudentProfile, SkillScore } from '../types';
import { DEFAULT_PROFILE } from '../data/constants';

const PROFILE_KEY = 'ai_skill_gap_profile_v2';
const SCORES_KEY = 'ai_skill_gap_scores_v2';

export function loadStoredProfile(): StudentProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.name) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading profile from localStorage', e);
  }
  return DEFAULT_PROFILE;
}

export function saveStoredProfile(profile: StudentProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed saving profile to localStorage', e);
  }
}

export function loadStoredScores(): Record<string, SkillScore> {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading scores from localStorage', e);
  }
  return {};
}

export function saveStoredScores(scores: Record<string, SkillScore>): void {
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(scores));
  } catch (e) {
    console.error('Failed saving scores to localStorage', e);
  }
}
